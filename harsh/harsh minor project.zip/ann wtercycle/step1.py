import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
import sys

def load_data(filepath):
    try:
        # Verify file exists
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
            
        # Verify file is not empty
        if os.path.getsize(filepath) == 0:
            raise ValueError("File is empty")
            
        # Try reading the file
        data = pd.read_csv(filepath)
        
        # Verify data was loaded correctly
        if data.empty:
            raise ValueError("No data loaded - file may be malformed")
            
        print("\n=== Data loaded successfully ===")
        print(f"Rows: {len(data)}, Columns: {len(data.columns)}")
        print("Columns:", list(data.columns))
        print("\nFirst 3 rows:")
        print(data.head(3))
        
        return data
        
    except Exception as e:
        print(f"\nERROR LOADING DATA: {str(e)}")
        print("\nTroubleshooting tips:")
        print("1. Verify the file exists in the correct location")
        print("2. Check the file has content (open it in a text editor)")
        print("3. Ensure the file is a proper CSV with comma separators")
        print("4. Make sure you have read permissions for the file")
        sys.exit(1)

def main():
    print("Starting Crop Yield Prediction Model")
    
    # Use raw string for path to avoid escape character issues
    DATA_FILE = r'C:\Users\yashw\Desktop\ann wtercycle\agricultural_data.csv'
    
    # Load data
    data = load_data(DATA_FILE)
    
    # Check if we have expected columns (case sensitive)
    required_columns = ['Temperature', 'Humidity', 'Precipitation', 'Evaporation', 'Crop_Yield']
    missing = [col for col in required_columns if col not in data.columns]
    
    if missing:
        print(f"\nERROR: Missing required columns: {missing}")
        print("Available columns:", list(data.columns))
        print("\nPlease ensure your CSV contains these exact column names:")
        print(required_columns)
        sys.exit(1)
    
    # Prepare data
    X = data[['Temperature', 'Humidity', 'Precipitation', 'Evaporation']]
    y = data['Crop_Yield']
    
    # Preprocessing
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
    
    # ANN Model
    model = Sequential([
        Dense(64, input_dim=X_train.shape[1], activation='relu'),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(1, activation='linear')
    ])
    
    model.compile(loss='mse', optimizer='adam', metrics=['mae'])
    
    print("\n=== Model Summary ===")
    model.summary()
    
    # Training
    print("\n=== Training Model ===")
    history = model.fit(X_train, y_train,
                      validation_data=(X_test, y_test),
                      epochs=100,
                      batch_size=32,
                      verbose=1)
    
    # Evaluation
    print("\n=== Evaluation ===")
    loss, mae = model.evaluate(X_test, y_test)
    print(f"Test MAE: {mae:.2f} (average error in yield units)")
    
    # Sample prediction
    print("\n=== Sample Prediction ===")
    sample = np.array([[30, 60, 100, 5.0]])  # Example values
    sample_scaled = scaler.transform(sample)
    predicted_yield = model.predict(sample_scaled)
    print(f"Predicted yield: {predicted_yield[0][0]:.2f}")
    
    print("\nModel training completed successfully!")

if __name__ == "__main__":
    main()