
import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star, ShoppingCart, IndianRupee } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useCart } from '@/contexts/CartContext';
import { Product } from '@/types/product';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  
  // Convert dollar to rupees (approx rate: 1 USD = 75 INR)
  const priceInRupees = product.price * 75;
  const originalPriceInRupees = product.originalPrice ? product.originalPrice * 75 : undefined;
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
  };
  
  const handleAddToWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toast.success(`${product.name} added to wishlist!`);
  };
  
  // Calculate discount percentage
  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;
  
  return (
    <Link to={`/product/${product.id}`} className="product-card group">
      <div className="relative">
        <img 
          src={product.image} 
          alt={product.name} 
          className="product-image group-hover:scale-105 transition-transform duration-300"
        />
        {discountPercentage > 0 && (
          <span className="badge-discount">{discountPercentage}% OFF</span>
        )}
        <button 
          onClick={handleAddToWishlist}
          className="absolute top-2 left-2 p-1.5 bg-white rounded-full shadow-sm hover:bg-gray-100"
        >
          <Heart size={18} className="text-gray-500 hover:text-accent2 transition-colors" />
        </button>
      </div>
      
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="font-medium text-gray-800 line-clamp-2 mb-1 flex-grow">{product.name}</h3>
        
        <div className="rating-stars mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                size={14} 
                className={i < Math.floor(product.rating) ? 'fill-accent2-dark text-accent2-dark' : 'text-gray-300'} 
              />
            ))}
          </div>
          <span className="text-xs text-gray-500 ml-1">({product.reviewCount})</span>
        </div>
        
        <div className="flex items-center mb-3">
          <span className="font-bold text-gray-800 flex items-center">
            <IndianRupee size={16} className="mr-1" />
            {priceInRupees.toFixed(2)}
          </span>
          {originalPriceInRupees && (
            <span className="text-gray-500 text-sm line-through ml-2 flex items-center">
              <IndianRupee size={12} className="mr-0.5" />
              {originalPriceInRupees.toFixed(2)}
            </span>
          )}
        </div>
        
        <Button 
          onClick={handleAddToCart} 
          variant="outline" 
          size="sm" 
          className="w-full mt-auto flex items-center justify-center"
        >
          <ShoppingCart size={16} className="mr-2" />
          Add to Cart
        </Button>
      </div>
    </Link>
  );
}
