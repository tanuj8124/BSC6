
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { IndianRupee } from 'lucide-react';

export default function CartSummary() {
  const { cartItems } = useCart();
  
  // Convert dollar to rupees (approx rate: 1 USD = 75 INR)
  const subtotalInDollars = cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const subtotal = subtotalInDollars * 75;
  const shippingInDollars = subtotalInDollars > 50 ? 0 : 5.99;
  const shipping = shippingInDollars * 75;
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + shipping + tax;
  
  return (
    <div className="bg-gray-50 rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
      
      <div className="space-y-3 border-b pb-4 mb-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Subtotal</span>
          <span className="flex items-center">
            <IndianRupee size={16} className="mr-1" />
            {subtotal.toFixed(2)}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Shipping</span>
          <span>{shipping === 0 ? 'Free' : (
            <span className="flex items-center">
              <IndianRupee size={16} className="mr-1" />
              {shipping.toFixed(2)}
            </span>
          )}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Tax (8%)</span>
          <span className="flex items-center">
            <IndianRupee size={16} className="mr-1" />
            {tax.toFixed(2)}
          </span>
        </div>
      </div>
      
      <div className="flex justify-between font-semibold text-lg mb-6 items-center">
        <span>Total</span>
        <span className="flex items-center">
          <IndianRupee size={16} className="mr-1" />
          {total.toFixed(2)}
        </span>
      </div>
      
      <Button asChild className="w-full mb-3">
        <Link to="/checkout">Proceed to Checkout</Link>
      </Button>
      
      <Button asChild variant="outline" className="w-full">
        <Link to="/">Continue Shopping</Link>
      </Button>
      
      <div className="mt-4 text-sm text-gray-500">
        <p>Free shipping on orders over ₹3,750</p>
        <p className="mt-2">We accept all major credit cards, PayPal, and more.</p>
      </div>
    </div>
  );
}
