
import React from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, IndianRupee } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { CartItemType } from '@/types/cart';

interface CartItemProps {
  item: CartItemType;
}

export default function CartItem({ item }: CartItemProps) {
  const { updateCartItemQuantity, removeFromCart } = useCart();
  
  // Convert dollar to rupees (approx rate: 1 USD = 75 INR)
  const priceInRupees = item.product.price * 75;
  const itemTotal = priceInRupees * item.quantity;
  
  const handleDecreaseQuantity = () => {
    if (item.quantity > 1) {
      updateCartItemQuantity(item.product.id, item.quantity - 1);
    } else {
      removeFromCart(item.product.id);
    }
  };
  
  const handleIncreaseQuantity = () => {
    updateCartItemQuantity(item.product.id, item.quantity + 1);
  };
  
  const handleRemove = () => {
    removeFromCart(item.product.id);
  };
  
  return (
    <div className="flex flex-col sm:flex-row py-6 border-b">
      <div className="flex-shrink-0 w-full sm:w-24 h-24 mb-4 sm:mb-0">
        <Link to={`/product/${item.product.id}`}>
          <img 
            src={item.product.image} 
            alt={item.product.name} 
            className="w-full h-full object-cover object-center"
          />
        </Link>
      </div>
      
      <div className="flex-grow sm:ml-6 flex flex-col sm:flex-row sm:items-center">
        <div className="flex-grow">
          <Link to={`/product/${item.product.id}`} className="text-lg font-medium hover:text-brand">
            {item.product.name}
          </Link>
          
          <div className="mt-1 text-sm text-gray-500">
            {item.product.category}
          </div>
          
          <div className="mt-1 font-medium flex items-center">
            <IndianRupee size={16} className="mr-1" />
            {priceInRupees.toFixed(2)}
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 sm:mt-0">
          <div className="flex items-center border rounded-md">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={handleDecreaseQuantity}
            >
              <Minus size={16} />
            </Button>
            <span className="w-8 text-center">{item.quantity}</span>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8" 
              onClick={handleIncreaseQuantity}
            >
              <Plus size={16} />
            </Button>
          </div>
          
          <div className="ml-6 sm:ml-8 font-medium flex items-center">
            <IndianRupee size={16} className="mr-1" />
            {itemTotal.toFixed(2)}
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="ml-4 text-gray-400 hover:text-destructive" 
            onClick={handleRemove}
          >
            <Trash2 size={18} />
          </Button>
        </div>
      </div>
    </div>
  );
}
