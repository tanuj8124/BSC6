
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Thanks for subscribing to our newsletter!');
      setEmail('');
    }
  };
  
  return (
    <section className="py-12 bg-brand text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-3">Subscribe to Our Newsletter</h2>
        <p className="text-lg text-white/80 mb-6 max-w-2xl mx-auto">
          Stay updated with our latest products, exclusive offers, and promotions. 
          Subscribe now and get 10% off your first order!
        </p>
        
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="Your email address"
            className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" className="bg-white text-brand hover:bg-white/90">
            Subscribe
          </Button>
        </form>
      </div>
    </section>
  );
}
