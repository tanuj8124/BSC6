
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export default function HeroBanner() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="animate-fade-in">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">Spring Sale</h1>
            <h2 className="text-xl md:text-3xl font-semibold mb-6">Up to 50% off on selected items</h2>
            <p className="text-lg mb-8 max-w-md">
              Discover amazing deals on our latest collection. Limited time offer!
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                <Link to="/sale">Shop Now</Link>
              </Button>
            </div>
          </div>
          <div className="hidden md:block relative">
            <img 
              src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?q=80&w=2340&auto=format&fit=crop"
              alt="Electronics sale" 
              className="rounded-lg shadow-lg object-cover h-96 w-full"
            />
            <div className="absolute -bottom-6 -left-6 bg-accent2 text-white p-4 rounded-lg shadow-lg">
              <span className="block text-2xl font-bold">50% OFF</span>
              <span className="text-sm">Limited time only</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
