
import React from 'react';
import { Link } from 'react-router-dom';

const categories = [
  {
    name: 'Electronics',
    image: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?q=80&w=1287&auto=format&fit=crop',
    path: '/category/electronics'
  },
  {
    name: 'Fashion',
    image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=1171&auto=format&fit=crop',
    path: '/category/fashion'
  },
  {
    name: 'Home & Kitchen',
    image: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=1170&auto=format&fit=crop',
    path: '/category/home-kitchen'
  },
  {
    name: 'Books',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=1173&auto=format&fit=crop',
    path: '/category/books'
  }
];

export default function FeaturedCategories() {
  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-center">Shop By Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {categories.map((category) => (
            <Link 
              key={category.name} 
              to={category.path}
              className="group relative rounded-lg overflow-hidden hover:shadow-md transition-all duration-200"
            >
              <div className="aspect-square">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center transition-opacity">
                <h3 className="text-white text-lg md:text-xl font-bold">{category.name}</h3>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
