
import React from 'react';
import ProductCard from '../product/ProductCard';
import { products } from '@/data/products';

export default function FeaturedProducts() {
  // Get only the first 8 products for featured section
  const featuredProducts = products.slice(0, 8);
  
  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-center">Featured Products</h2>
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
