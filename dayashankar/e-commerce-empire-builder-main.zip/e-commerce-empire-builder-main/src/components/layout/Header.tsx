
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Search, Heart, Menu, User, X, Home, LogOut, Settings, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useIsMobile } from '@/hooks/use-mobile';
import { useCart } from '@/contexts/CartContext';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

const categories = [
  { name: 'Electronics', path: '/category/electronics' },
  { name: 'Fashion', path: '/category/fashion' },
  { name: 'Home & Kitchen', path: '/category/home-kitchen' },
  { name: 'Books', path: '/category/books' },
  { name: 'Toys', path: '/category/toys' },
];

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const isMobile = useIsMobile();
  const { cartItems } = useCart();
  const navigate = useNavigate();
  
  useEffect(() => {
    // Check authentication status whenever component mounts or updates
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    const role = localStorage.getItem('userRole');
    setIsAuthenticated(authStatus);
    setUserRole(role);
  }, []);
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    setIsAuthenticated(false);
    setUserRole(null);
    navigate('/');
  };

  const getDashboardLink = () => {
    if (!isAuthenticated) return '/login';
    
    switch (userRole) {
      case 'admin':
        return '/admin-dashboard';
      case 'seller':
        return '/seller-dashboard';
      default:
        return '/dashboard';
    }
  };
  
  return (
    <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <h1 className="text-2xl font-bold text-brand">Everything Store</h1>
          </Link>
          
          {/* Search Bar - Hide on mobile */}
          {!isMobile && (
            <div className="w-full max-w-xl px-4">
              <div className="relative">
                <Input 
                  type="text" 
                  placeholder="Search products..." 
                  className="pl-10 pr-4 py-2 w-full"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              </div>
            </div>
          )}
          
          {/* Navigation for desktop */}
          {!isMobile && (
            <nav className="hidden md:flex items-center space-x-6">
              <Link to="/" className="flex items-center text-gray-700 hover:text-brand">
                <Home size={20} className="mr-1" />
                <span>Home</span>
              </Link>
              <Link to="/about" className="flex items-center text-gray-700 hover:text-brand">
                <span>About</span>
              </Link>
              <Link to="/wishlist" className="flex items-center text-gray-700 hover:text-brand">
                <Heart size={20} />
                <span className="ml-1">Wishlist</span>
              </Link>
              <Link to="/cart" className="flex items-center text-gray-700 hover:text-brand relative">
                <ShoppingCart size={20} />
                <span className="ml-1">Cart</span>
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-accent2 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </Link>
              
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center">
                      <User size={20} className="mr-2" />
                      {userRole ? userRole.charAt(0).toUpperCase() + userRole.slice(1) : 'Account'}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem onClick={() => navigate(getDashboardLink())}>
                      {userRole === 'admin' && <Settings size={16} className="mr-2" />}
                      {userRole === 'seller' && <Package size={16} className="mr-2" />}
                      {(!userRole || userRole === 'customer') && <User size={16} className="mr-2" />}
                      Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500">
                      <LogOut size={16} className="mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center">
                      <User size={20} className="mr-2" />
                      Login
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem onClick={() => navigate('/login')}>
                      <User size={16} className="mr-2" />
                      Customer Login
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/admin-login')}>
                      <Settings size={16} className="mr-2" />
                      Admin/Seller Login
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </nav>
          )}
          
          {/* Mobile menu button */}
          {isMobile && (
            <div className="flex items-center">
              <Link to="/cart" className="mr-4 relative">
                <ShoppingCart size={24} />
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-accent2 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </Link>
              <button onClick={toggleMenu} className="text-gray-700">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          )}
        </div>
        
        {/* Mobile search bar */}
        {isMobile && (
          <div className="mt-3">
            <div className="relative">
              <Input 
                type="text" 
                placeholder="Search products..." 
                className="pl-10 pr-4 py-2 w-full"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
          </div>
        )}
        
        {/* Category navigation - Desktop */}
        {!isMobile && (
          <nav className="hidden md:flex items-center justify-center mt-4 space-x-8">
            {categories.map((category) => (
              <Link 
                key={category.name} 
                to={category.path} 
                className="text-gray-700 hover:text-brand font-medium"
              >
                {category.name}
              </Link>
            ))}
          </nav>
        )}
        
        {/* Mobile menu */}
        {isMobile && isMenuOpen && (
          <div className="fixed inset-0 bg-white z-50 pt-16 px-4">
            <div className="flex flex-col space-y-4">
              <Link to="/" className="flex items-center py-3 border-b" onClick={toggleMenu}>
                <Home size={20} className="mr-3" />
                <span>Home</span>
              </Link>
              <Link to="/about" className="flex items-center py-3 border-b" onClick={toggleMenu}>
                <span>About</span>
              </Link>
              
              {isAuthenticated ? (
                <>
                  <Link to={getDashboardLink()} className="flex items-center py-3 border-b" onClick={toggleMenu}>
                    {userRole === 'admin' && <Settings size={20} className="mr-3" />}
                    {userRole === 'seller' && <Package size={20} className="mr-3" />}
                    {(!userRole || userRole === 'customer') && <User size={20} className="mr-3" />}
                    <span>Dashboard</span>
                  </Link>
                  <button 
                    className="flex items-center py-3 border-b text-red-500" 
                    onClick={() => {
                      handleLogout();
                      toggleMenu();
                    }}
                  >
                    <LogOut size={20} className="mr-3" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="flex items-center py-3 border-b" onClick={toggleMenu}>
                    <User size={20} className="mr-3" />
                    <span>Customer Login</span>
                  </Link>
                  <Link to="/admin-login" className="flex items-center py-3 border-b" onClick={toggleMenu}>
                    <Settings size={20} className="mr-3" />
                    <span>Admin/Seller Login</span>
                  </Link>
                </>
              )}
              
              <Link to="/wishlist" className="flex items-center py-3 border-b" onClick={toggleMenu}>
                <Heart size={20} className="mr-3" />
                <span>Wishlist</span>
              </Link>
              
              <div className="py-2">
                <h3 className="font-semibold text-lg mb-2">Categories</h3>
                <ul className="space-y-3">
                  {categories.map((category) => (
                    <li key={category.name}>
                      <Link 
                        to={category.path} 
                        className="block py-2 text-gray-700"
                        onClick={toggleMenu}
                      >
                        {category.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
