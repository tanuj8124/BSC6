import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-100 pt-12 mt-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Everything Store</h3>
            <p className="text-gray-600 mb-4">
              Your one-stop shop for all your shopping needs. Find the best products at great prices.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-brand">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-500 hover:text-brand">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-500 hover:text-brand">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-500 hover:text-brand">
                <Youtube size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-700 mb-4">Shop</h4>
            <ul className="space-y-2">
              <li><Link to="/category/electronics" className="text-gray-600 hover:text-brand">Electronics</Link></li>
              <li><Link to="/category/fashion" className="text-gray-600 hover:text-brand">Fashion</Link></li>
              <li><Link to="/category/home-kitchen" className="text-gray-600 hover:text-brand">Home & Kitchen</Link></li>
              <li><Link to="/category/books" className="text-gray-600 hover:text-brand">Books</Link></li>
              <li><Link to="/category/toys" className="text-gray-600 hover:text-brand">Toys</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-700 mb-4">Customer Service</h4>
            <ul className="space-y-2">
              <li><Link to="/contact" className="text-gray-600 hover:text-brand">Contact Us</Link></li>
              <li><Link to="/about" className="text-gray-600 hover:text-brand">About Us</Link></li>
              <li><Link to="/faq" className="text-gray-600 hover:text-brand">FAQ</Link></li>
              <li><Link to="/shipping" className="text-gray-600 hover:text-brand">Shipping Policy</Link></li>
              <li><Link to="/returns" className="text-gray-600 hover:text-brand">Returns & Refunds</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-700 mb-4">Contact Info</h4>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 text-gray-500 mt-1" />
                <span className="text-gray-600">123 Commerce St, Shopping City, SC 12345</span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="mr-2 text-gray-500" />
                <span className="text-gray-600">(123) 456-7890</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 text-gray-500" />
                <span className="text-gray-600">support@shophub.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 text-sm">
              &copy; {new Date().getFullYear()} ShopHub. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link to="/privacy" className="text-gray-600 hover:text-brand text-sm">Privacy Policy</Link>
              <Link to="/terms" className="text-gray-600 hover:text-brand text-sm">Terms of Service</Link>
              <Link to="/cookies" className="text-gray-600 hover:text-brand text-sm">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
