
import { Product } from '@/types/product';

export const products: Product[] = [
  {
    id: 1,
    name: 'Premium Wireless Headphones',
    price: 179.99,
    originalPrice: 249.99,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1470&auto=format&fit=crop',
    description: 'Experience premium sound quality with our noise-cancelling wireless headphones. Perfect for music lovers and professionals alike.',
    category: 'Electronics',
    subcategory: 'Audio',
    rating: 4.8,
    reviewCount: 352,
    inStock: true,
    features: [
      'Active noise cancellation',
      'Up to 30 hours battery life',
      'Bluetooth 5.0 connectivity',
      'Premium sound quality',
      'Built-in microphone'
    ]
  },
  {
    id: 2,
    name: 'Ultra HD Smart TV - 55"',
    price: 699.99,
    originalPrice: 899.99,
    image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?q=80&w=1470&auto=format&fit=crop',
    category: 'Electronics',
    subcategory: 'Televisions',
    rating: 4.6,
    reviewCount: 189,
    inStock: true
  },
  {
    id: 3,
    name: 'Professional Camera Kit',
    price: 1299.99,
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=1538&auto=format&fit=crop',
    category: 'Electronics',
    subcategory: 'Cameras',
    rating: 4.9,
    reviewCount: 87,
    inStock: true
  },
  {
    id: 4,
    name: 'Ergonomic Office Chair',
    price: 249.99,
    originalPrice: 299.99,
    image: 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?q=80&w=1374&auto=format&fit=crop',
    category: 'Home & Kitchen',
    subcategory: 'Furniture',
    rating: 4.5,
    reviewCount: 132,
    inStock: true
  },
  {
    id: 5,
    name: 'Stainless Steel Cookware Set',
    price: 189.99,
    originalPrice: 249.99,
    image: 'https://images.unsplash.com/photo-1584824486539-53bb4646bdbc?q=80&w=1374&auto=format&fit=crop',
    category: 'Home & Kitchen',
    subcategory: 'Cookware',
    rating: 4.7,
    reviewCount: 98,
    inStock: true
  },
  {
    id: 6,
    name: 'Classic Leather Wallet',
    price: 49.99,
    image: 'https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=1374&auto=format&fit=crop',
    category: 'Fashion',
    subcategory: 'Accessories',
    rating: 4.4,
    reviewCount: 211,
    inStock: true
  },
  {
    id: 8,
    name: 'Bestselling Fiction Novel',
    price: 15.99,
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=1374&auto=format&fit=crop',
    category: 'Books',
    subcategory: 'Fiction',
    rating: 4.8,
    reviewCount: 326,
    inStock: true
  },
  {
    id: 9,
    name: 'Smartphone Stand and Charger',
    price: 34.99,
    originalPrice: 49.99,
    image: 'https://images.unsplash.com/photo-1609692814859-8c4f2b8ee7a2?q=80&w=1470&auto=format&fit=crop',
    category: 'Electronics',
    subcategory: 'Mobile Accessories',
    rating: 4.3,
    reviewCount: 78,
    inStock: true
  },
  {
    id: 10,
    name: 'Casual Denim Jacket',
    price: 79.99,
    originalPrice: 99.99,
    image: 'https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?q=80&w=1369&auto=format&fit=crop',
    category: 'Fashion',
    subcategory: 'Outerwear',
    rating: 4.5,
    reviewCount: 112,
    inStock: true
  },
  {
    id: 11,
    name: 'Outdoor Camping Tent - 4 Person',
    price: 149.99,
    originalPrice: 199.99,
    image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?q=80&w=1470&auto=format&fit=crop',
    category: 'Sports & Outdoors',
    subcategory: 'Camping',
    rating: 4.4,
    reviewCount: 94,
    inStock: true
  },
  {
    id: 12,
    name: 'Smartwatch with Fitness Tracker',
    price: 129.99,
    originalPrice: 159.99,
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=1472&auto=format&fit=crop',
    category: 'Electronics',
    subcategory: 'Wearables',
    rating: 4.7,
    reviewCount: 157,
    inStock: true
  },
  {
    id: 13,
    name: 'Luxury Scented Candle Set',
    price: 39.99,
    originalPrice: 59.99,
    image: 'https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?q=80&w=1470&auto=format&fit=crop',
    category: 'Home & Kitchen',
    subcategory: 'Home Decor',
    rating: 4.6,
    reviewCount: 87,
    inStock: true
  },
  {
    id: 14,
    name: 'Modern Coffee Table',
    price: 199.99,
    originalPrice: 249.99,
    image: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04?q=80&w=1470&auto=format&fit=crop',
    category: 'Home & Kitchen',
    subcategory: 'Furniture',
    rating: 4.5,
    reviewCount: 62,
    inStock: true
  },
  {
    id: 15,
    name: 'Pet Grooming Kit',
    price: 45.99,
    originalPrice: 59.99,
    image: 'https://images.unsplash.com/photo-1582562124811-c09040d0a901?q=80&w=1470&auto=format&fit=crop',
    category: 'Pets',
    subcategory: 'Pet Care',
    rating: 4.3,
    reviewCount: 124,
    inStock: true
  },
  {
    id: 16,
    name: 'Hiking Backpack - 40L',
    price: 89.99,
    originalPrice: 119.99,
    image: 'https://images.unsplash.com/photo-1493962853295-0fd70327578a?q=80&w=1470&auto=format&fit=crop',
    category: 'Sports & Outdoors',
    subcategory: 'Hiking',
    rating: 4.7,
    reviewCount: 108,
    inStock: true
  }
];
