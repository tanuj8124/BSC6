
import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, IndianRupee } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import MainLayout from '@/components/layout/MainLayout';
import { products } from '@/data/products';
import { useCart } from '@/contexts/CartContext';

// Mock wishlist items (usually would be from a context or other state management)
const wishlistItems = products.slice(0, 4);

const WishlistPage = () => {
  const { addToCart } = useCart();
  
  const handleRemoveFromWishlist = (productId: number) => {
    toast.success('Product removed from wishlist!');
  };
  
  const handleMoveToCart = (productId: number) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      addToCart(product);
      toast.success(`${product.name} added to cart!`);
    }
  };
  
  // Convert dollar to rupees (approx rate: 1 USD = 75 INR)
  const convertToRupees = (dollarPrice: number) => dollarPrice * 75;
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-8">My Wishlist</h1>
        
        {wishlistItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Heart size={64} className="text-gray-300 mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Your wishlist is empty</h2>
            <p className="text-gray-500 mb-6">Save items you love to your wishlist and review them anytime.</p>
            <Button asChild>
              <Link to="/">Start Shopping</Link>
            </Button>
          </div>
        ) : (
          <div className="border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Product
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Price
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {wishlistItems.map((product) => (
                    <tr key={product.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-16 w-16">
                            <img 
                              src={product.image} 
                              alt={product.name} 
                              className="h-16 w-16 object-cover"
                            />
                          </div>
                          <div className="ml-4">
                            <Link to={`/product/${product.id}`} className="text-sm font-medium text-gray-900 hover:text-brand">
                              {product.name}
                            </Link>
                            <div className="text-sm text-gray-500">{product.category}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900 flex items-center">
                          <IndianRupee size={14} className="mr-1" />
                          {convertToRupees(product.price).toFixed(2)}
                        </div>
                        {product.originalPrice && (
                          <div className="text-sm text-gray-500 line-through flex items-center">
                            <IndianRupee size={12} className="mr-0.5" />
                            {convertToRupees(product.originalPrice).toFixed(2)}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          In Stock
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleMoveToCart(product.id)}
                          >
                            Add to Cart
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="text-gray-500 hover:text-destructive"
                            onClick={() => handleRemoveFromWishlist(product.id)}
                          >
                            Remove
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default WishlistPage;
