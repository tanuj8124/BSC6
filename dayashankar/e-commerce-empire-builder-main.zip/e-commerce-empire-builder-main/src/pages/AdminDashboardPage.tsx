import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import {
  LayoutDashboard,
  Users,
  Package,
  ShoppingCart,
  Settings,
  LogOut,
  UserPlus,
} from 'lucide-react';

// Mock data
const mockProducts = [
  { id: 1, name: 'Premium Headphones', price: 199.99, stock: 45, status: 'In Stock' },
  { id: 2, name: 'Wireless Mouse', price: 49.99, stock: 12, status: 'Low Stock' },
  { id: 3, name: 'Mechanical Keyboard', price: 129.99, stock: 0, status: 'Out of Stock' },
  { id: 4, name: 'Gaming Monitor', price: 299.99, stock: 8, status: 'Low Stock' },
  { id: 5, name: 'USB-C Charger', price: 29.99, stock: 67, status: 'In Stock' },
];

const mockUsers = [
  { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Customer', status: 'Active' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Customer', status: 'Active' },
  { id: 3, name: 'Mike Johnson', email: 'mike@example.com', role: 'Seller', status: 'Inactive' },
  { id: 4, name: 'Sarah Brown', email: 'sarah@example.com', role: 'Customer', status: 'Active' },
];

const mockOrders = [
  { id: 'ORD-2023-001', customer: 'John Doe', date: '2023-05-12', total: 249.98, status: 'Delivered' },
  { id: 'ORD-2023-002', customer: 'Jane Smith', date: '2023-05-14', total: 129.99, status: 'Processing' },
  { id: 'ORD-2023-003', customer: 'Mike Johnson', date: '2023-05-16', total: 79.98, status: 'Shipped' },
  { id: 'ORD-2023-004', customer: 'Sarah Brown', date: '2023-05-18', total: 329.97, status: 'Pending' },
];

const AdminDashboardPage = () => {
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated and has admin role
    const isAuth = localStorage.getItem('isAuthenticated');
    const email = localStorage.getItem('userEmail');
    const role = localStorage.getItem('userRole');
    
    if (!isAuth || !email || role !== 'admin') {
      // Redirect to admin login if not authenticated as admin
      toast.error('Please login as admin to access this page');
      navigate('/admin-login');
      return;
    }
    
    setUserEmail(email);
    setUserRole(role);
    setIsLoading(false);
  }, [navigate]);

  const handleLogout = () => {
    // Clear authentication data
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    
    // Show success message and redirect to admin login
    toast.success('Successfully logged out');
    navigate('/admin-login');
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12 flex items-center justify-center">
          <p>Loading admin dashboard...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-1/4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users size={20} />
                  <span>Admin Panel</span>
                </CardTitle>
                <CardDescription>
                  {userEmail} <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">Admin</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant={activeTab === 'overview' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('overview')}
                  >
                    <LayoutDashboard size={18} className="mr-2" />
                    Overview
                  </Button>
                  <Button 
                    variant={activeTab === 'products' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('products')}
                  >
                    <Package size={18} className="mr-2" />
                    Products
                  </Button>
                  <Button 
                    variant={activeTab === 'orders' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('orders')}
                  >
                    <ShoppingCart size={18} className="mr-2" />
                    Orders
                  </Button>
                  <Button 
                    variant={activeTab === 'users' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('users')}
                  >
                    <Users size={18} className="mr-2" />
                    Users
                  </Button>
                  <Button 
                    variant={activeTab === 'settings' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('settings')}
                  >
                    <Settings size={18} className="mr-2" />
                    Settings
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-50" 
                    onClick={handleLogout}
                  >
                    <LogOut size={18} className="mr-2" />
                    Logout
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="w-full md:w-3/4">
            {activeTab === 'overview' && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Admin Dashboard</CardTitle>
                  <CardDescription>Welcome to the admin control panel.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Total Products</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{mockProducts.length}</div>
                        <p className="text-xs text-muted-foreground">5 products in catalog</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Users</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{mockUsers.length}</div>
                        <p className="text-xs text-muted-foreground">3 active users</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Recent Orders</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{mockOrders.length}</div>
                        <p className="text-xs text-muted-foreground">2 pending orders</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="font-medium mb-3">Recent Activity</h3>
                    <div className="rounded-md border">
                      <div className="p-4 border-b">
                        <p className="text-sm font-medium">New order #ORD-2023-004 received</p>
                        <p className="text-xs text-muted-foreground mt-1">Today at 10:32 AM</p>
                      </div>
                      <div className="p-4 border-b">
                        <p className="text-sm font-medium">Product "Wireless Mouse" low stock alert</p>
                        <p className="text-xs text-muted-foreground mt-1">Today at 9:15 AM</p>
                      </div>
                      <div className="p-4">
                        <p className="text-sm font-medium">New user registered: Sarah Brown</p>
                        <p className="text-xs text-muted-foreground mt-1">Yesterday at 3:45 PM</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'products' && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Products</CardTitle>
                      <CardDescription>Manage your product catalog.</CardDescription>
                    </div>
                    <Button size="sm">
                      <Package size={16} className="mr-2" />
                      Add Product
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">ID</th>
                          <th className="px-4 py-3">Product Name</th>
                          <th className="px-4 py-3">Price</th>
                          <th className="px-4 py-3">Stock</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockProducts.map((product) => (
                          <tr key={product.id} className="bg-white border-b">
                            <td className="px-4 py-3">{product.id}</td>
                            <td className="px-4 py-3">{product.name}</td>
                            <td className="px-4 py-3">${product.price.toFixed(2)}</td>
                            <td className="px-4 py-3">{product.stock}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block px-2 py-1 rounded text-xs ${
                                product.status === 'In Stock' 
                                  ? 'bg-green-100 text-green-800' 
                                  : product.status === 'Low Stock' 
                                    ? 'bg-yellow-100 text-yellow-800' 
                                    : 'bg-red-100 text-red-800'
                              }`}>
                                {product.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="outline" size="sm" className="text-red-500">Delete</Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'orders' && (
              <Card>
                <CardHeader>
                  <CardTitle>Orders</CardTitle>
                  <CardDescription>View and manage customer orders.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">Order ID</th>
                          <th className="px-4 py-3">Customer</th>
                          <th className="px-4 py-3">Date</th>
                          <th className="px-4 py-3">Total</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockOrders.map((order) => (
                          <tr key={order.id} className="bg-white border-b">
                            <td className="px-4 py-3">{order.id}</td>
                            <td className="px-4 py-3">{order.customer}</td>
                            <td className="px-4 py-3">{order.date}</td>
                            <td className="px-4 py-3">${order.total.toFixed(2)}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block px-2 py-1 rounded text-xs ${
                                order.status === 'Delivered' 
                                  ? 'bg-green-100 text-green-800' 
                                  : order.status === 'Shipped' 
                                    ? 'bg-blue-100 text-blue-800' 
                                    : order.status === 'Processing' 
                                      ? 'bg-yellow-100 text-yellow-800' 
                                      : 'bg-gray-100 text-gray-800'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">View</Button>
                                <Button variant="outline" size="sm">Update</Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'users' && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Users</CardTitle>
                      <CardDescription>Manage user accounts.</CardDescription>
                    </div>
                    <Button size="sm">
                      <UserPlus size={16} className="mr-2" />
                      Add User
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">ID</th>
                          <th className="px-4 py-3">Name</th>
                          <th className="px-4 py-3">Email</th>
                          <th className="px-4 py-3">Role</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockUsers.map((user) => (
                          <tr key={user.id} className="bg-white border-b">
                            <td className="px-4 py-3">{user.id}</td>
                            <td className="px-4 py-3">{user.name}</td>
                            <td className="px-4 py-3">{user.email}</td>
                            <td className="px-4 py-3">{user.role}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block px-2 py-1 rounded text-xs ${
                                user.status === 'Active' 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {user.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="outline" size="sm" className="text-red-500">Disable</Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'settings' && (
              <Card>
                <CardHeader>
                  <CardTitle>Settings</CardTitle>
                  <CardDescription>Manage admin panel settings.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Store Name</label>
                        <Input defaultValue="Everything Store" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Contact Email</label>
                        <Input defaultValue="contact@example.com" />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Store Description</label>
                      <textarea 
                        className="w-full min-h-[100px] p-2 border rounded-md" 
                        defaultValue="Your one-stop shop for all your needs."
                      />
                    </div>
                    
                    <Button>Save Settings</Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default AdminDashboardPage;
