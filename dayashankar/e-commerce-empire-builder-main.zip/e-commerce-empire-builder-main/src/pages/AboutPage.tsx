
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';

export default function AboutPage() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8">About Us</h1>
        
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Welcome to Everything Store, your number one source for all things shopping. We're dedicated to providing you the very best of products, with an emphasis on quality, customer service, and uniqueness.
            </p>
            <p className="text-gray-700 leading-relaxed mb-4">
              Founded in 2023, Everything Store has come a long way from its beginnings. We now serve customers all over the world, and are thrilled to be a part of the eco-friendly wing of the shopping industry.
            </p>
            <p className="text-gray-700 leading-relaxed">
              We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.
            </p>
          </div>
          
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
            <p className="text-gray-700 leading-relaxed">
              At Everything Store, we believe that shopping should be easy, fun, and accessible to everyone. Our mission is to provide a wide selection of high-quality products at affordable prices, while offering exceptional customer service and a seamless shopping experience.
            </p>
          </div>
          
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Our Values</h2>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li>Customer satisfaction is our top priority</li>
              <li>Quality products at competitive prices</li>
              <li>Sustainable and ethical business practices</li>
              <li>Innovation and continuous improvement</li>
              <li>Honesty, transparency, and integrity in all our dealings</li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
