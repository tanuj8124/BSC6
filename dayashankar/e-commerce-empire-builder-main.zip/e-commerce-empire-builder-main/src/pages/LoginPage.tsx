import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, Facebook, Github, User, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import MainLayout from '@/components/layout/MainLayout';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<string | null>(null);
  const [showAccountDialog, setShowAccountDialog] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [showNewAccountInput, setShowNewAccountInput] = useState(false);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountEmail, setNewAccountEmail] = useState('');
  const navigate = useNavigate();
  
  // Mock accounts for demonstration
  const mockAccounts = [
    { id: 1, email: 'john.doe@gmail.com', provider: 'google', name: 'John Doe' },
    { id: 2, email: 'jane.smith@gmail.com', provider: 'google', name: 'Jane Smith' },
    { id: 3, email: 'alex.taylor@facebook.com', provider: 'facebook', name: 'Alex Taylor' }
  ];
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    
    try {
      setIsLoading(true);
      
      // For demo purposes - simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Successful login flow
      toast.success('Login successful!');
      
      // Store user session info in localStorage
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userEmail', email);
      
      // Redirect to home page after successful login
      setTimeout(() => {
        navigate('/');
      }, 500);
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSocialLoginInitiate = (provider: string) => {
    setSelectedProvider(provider);
    setShowAccountDialog(true);
    setShowNewAccountInput(false); // Reset to accounts view when opening dialog
  };
  
  const handleAccountSelection = async (account: any) => {
    setShowAccountDialog(false);
    setShowNewAccountInput(false);
    const provider = account.provider;
    setSocialLoading(provider);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store user session info
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userEmail', account.email);
      localStorage.setItem('userName', account.name);
      localStorage.setItem('loginProvider', provider);
      
      toast.success(`Login with ${account.name}'s ${provider} account successful!`);
      
      // Redirect to home page
      setTimeout(() => {
        navigate('/');
      }, 500);
    } catch (error) {
      console.error(`${provider} login error:`, error);
      toast.error(`${provider} login failed. Please try again.`);
    } finally {
      setSocialLoading(null);
    }
  };
  
  const handleAddNewAccount = () => {
    setShowNewAccountInput(true);
  };
  
  const handleNewAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newAccountName || !newAccountEmail) {
      toast.error('Please fill in all fields');
      return;
    }
    
    // Create a new account object
    const newAccount = {
      id: mockAccounts.length + 1,
      email: newAccountEmail,
      provider: selectedProvider,
      name: newAccountName
    };
    
    // Simulate adding account
    setSocialLoading(selectedProvider);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Close dialogs and reset states
      setShowAccountDialog(false);
      setShowNewAccountInput(false);
      setNewAccountName('');
      setNewAccountEmail('');
      
      // Login with the new account
      handleAccountSelection(newAccount);
      
      toast.success(`New ${selectedProvider} account added successfully!`);
    } catch (error) {
      console.error(`Add account error:`, error);
      toast.error(`Failed to add new account. Please try again.`);
      setSocialLoading(null);
    }
  };
  
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-sm border p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold">Welcome Back</h1>
            <p className="text-gray-600 mt-2">Sign in to your account to continue</p>
          </div>
          
          <form onSubmit={handleLogin}>
            <div className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail size={18} className="text-gray-400" />
                  </div>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    className="pl-10"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock size={18} className="text-gray-400" />
                  </div>
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="pl-10 pr-10"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={toggleShowPassword}
                  >
                    {showPassword ? (
                      <EyeOff size={18} className="text-gray-400" />
                    ) : (
                      <Eye size={18} className="text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <label className="flex items-center">
                  <input type="checkbox" className="rounded border-gray-300 text-brand shadow-sm focus:border-brand focus:ring focus:ring-brand focus:ring-opacity-50" />
                  <span className="ml-2 text-sm text-gray-600">Remember me</span>
                </label>
                <Link to="/forgot-password" className="text-sm text-brand hover:text-brand-dark">
                  Forgot password?
                </Link>
              </div>
              
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Signing In...' : 'Sign In'}
              </Button>
            </div>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Don't have an account?{' '}
              <Link to="/signup" className="text-brand hover:text-brand-dark font-medium">
                Create one now
              </Link>
            </p>
          </div>
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Or continue with</span>
              </div>
            </div>
            
            <div className="mt-6 grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => handleSocialLoginInitiate('google')}
                disabled={!!socialLoading}
              >
                {socialLoading === 'google' ? (
                  <div className="flex items-center">
                    <div className="w-4 h-4 border-2 border-t-transparent border-primary rounded-full animate-spin mr-2"></div>
                    <span>Signing in...</span>
                  </div>
                ) : (
                  <>
                    <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24">
                      <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
                        <path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 53.749 L -8.284 53.749 C -8.574 55.229 -9.424 56.479 -10.684 57.329 L -10.684 60.329 L -6.824 60.329 C -4.564 58.239 -3.264 55.159 -3.264 51.509 Z" />
                        <path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.329 L -10.684 57.329 C -11.764 58.049 -13.134 58.489 -14.754 58.489 C -17.884 58.489 -20.534 56.379 -21.484 53.529 L -25.464 53.529 L -25.464 56.619 C -23.494 60.539 -19.444 63.239 -14.754 63.239 Z" />
                        <path fill="#FBBC05" d="M -21.484 53.529 C -21.734 52.809 -21.864 52.039 -21.864 51.239 C -21.864 50.439 -21.724 49.669 -21.484 48.949 L -21.484 45.859 L -25.464 45.859 C -26.284 47.479 -26.754 49.299 -26.754 51.239 C -26.754 53.179 -26.284 54.999 -25.464 56.619 L -21.484 53.529 Z" />
                        <path fill="#EA4335" d="M -14.754 43.989 C -12.984 43.989 -11.404 44.599 -10.154 45.789 L -6.734 42.369 C -8.804 40.429 -11.514 39.239 -14.754 39.239 C -19.444 39.239 -23.494 41.939 -25.464 45.859 L -21.484 48.949 C -20.534 46.099 -17.884 43.989 -14.754 43.989 Z" />
                      </g>
                    </svg>
                    Google
                  </>
                )}
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleSocialLoginInitiate('facebook')}
                disabled={!!socialLoading}
              >
                {socialLoading === 'facebook' ? (
                  <div className="flex items-center">
                    <div className="w-4 h-4 border-2 border-t-transparent border-primary rounded-full animate-spin mr-2"></div>
                    <span>Signing in...</span>
                  </div>
                ) : (
                  <>
                    <Facebook className="h-5 w-5 mr-2 text-[#1877F2]" />
                    Facebook
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Account Selection Dialog */}
      <Dialog open={showAccountDialog} onOpenChange={setShowAccountDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {showNewAccountInput 
                ? `Add new ${selectedProvider} account` 
                : 'Choose an account'}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {!showNewAccountInput ? (
              <>
                {mockAccounts
                  .filter(account => !selectedProvider || account.provider === selectedProvider)
                  .map(account => (
                    <button
                      key={account.id}
                      className="w-full flex items-center p-3 hover:bg-gray-50 rounded-md mb-2 transition-colors border"
                      onClick={() => handleAccountSelection(account)}
                    >
                      <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                        <User size={20} className="text-gray-600" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium">{account.name}</p>
                        <p className="text-sm text-gray-500">{account.email}</p>
                      </div>
                    </button>
                  ))}
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={handleAddNewAccount}
                  >
                    <Plus size={16} className="mr-2" />
                    Use another account
                  </Button>
                </div>
              </>
            ) : (
              <form onSubmit={handleNewAccountSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Name
                  </label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Full Name"
                    value={newAccountName}
                    onChange={(e) => setNewAccountName(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="newEmail" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <Input
                    id="newEmail"
                    type="email"
                    placeholder="you@example.com"
                    value={newAccountEmail}
                    onChange={(e) => setNewAccountEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setShowNewAccountInput(false)}
                  >
                    Back
                  </Button>
                  <Button type="submit" className="flex-1" disabled={socialLoading !== null}>
                    {socialLoading ? 'Adding...' : 'Add Account'}
                  </Button>
                </div>
              </form>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default LoginPage;
