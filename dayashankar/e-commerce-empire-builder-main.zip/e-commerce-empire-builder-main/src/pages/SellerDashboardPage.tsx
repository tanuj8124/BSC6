
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Settings,
  LogOut,
  DollarSign,
} from 'lucide-react';

// Mock data
const mockSellerProducts = [
  { id: 1, name: 'Premium Headphones', price: 199.99, stock: 45, sold: 23, revenue: 4599.77 },
  { id: 2, name: 'Wireless Mouse', price: 49.99, stock: 12, sold: 17, revenue: 849.83 },
  { id: 3, name: 'Mechanical Keyboard', price: 129.99, stock: 0, sold: 8, revenue: 1039.92 },
];

const mockSellerOrders = [
  { id: 'ORD-2023-001', customer: 'John Doe', product: 'Premium Headphones', date: '2023-05-12', amount: 199.99, status: 'Delivered' },
  { id: 'ORD-2023-002', customer: 'Jane Smith', product: 'Mechanical Keyboard', date: '2023-05-14', amount: 129.99, status: 'Processing' },
  { id: 'ORD-2023-003', customer: 'Mike Johnson', product: 'Wireless Mouse', date: '2023-05-16', amount: 49.99, status: 'Shipped' },
  { id: 'ORD-2023-004', customer: 'Sarah Brown', product: 'Premium Headphones', date: '2023-05-18', amount: 199.99, status: 'Pending' },
];

const SellerDashboardPage = () => {
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated and has seller role
    const isAuth = localStorage.getItem('isAuthenticated');
    const email = localStorage.getItem('userEmail');
    const role = localStorage.getItem('userRole');
    
    if (!isAuth || !email || role !== 'seller') {
      // Redirect to admin login if not authenticated as seller
      toast.error('Please login as seller to access this page');
      navigate('/admin-login');
      return;
    }
    
    setUserEmail(email);
    setUserRole(role);
    setIsLoading(false);
  }, [navigate]);

  const handleLogout = () => {
    // Clear authentication data
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    
    // Show success message and redirect to admin login
    toast.success('Successfully logged out');
    navigate('/admin-login');
  };

  // Calculate total revenue
  const totalRevenue = mockSellerProducts.reduce((sum, product) => sum + product.revenue, 0);
  
  // Calculate total products sold
  const totalSold = mockSellerProducts.reduce((sum, product) => sum + product.sold, 0);

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12 flex items-center justify-center">
          <p>Loading seller dashboard...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-1/4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package size={20} />
                  <span>Seller Portal</span>
                </CardTitle>
                <CardDescription>
                  {userEmail} <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Seller</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant={activeTab === 'overview' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('overview')}
                  >
                    <LayoutDashboard size={18} className="mr-2" />
                    Overview
                  </Button>
                  <Button 
                    variant={activeTab === 'products' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('products')}
                  >
                    <Package size={18} className="mr-2" />
                    My Products
                  </Button>
                  <Button 
                    variant={activeTab === 'orders' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('orders')}
                  >
                    <ShoppingCart size={18} className="mr-2" />
                    My Orders
                  </Button>
                  <Button 
                    variant={activeTab === 'earnings' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('earnings')}
                  >
                    <DollarSign size={18} className="mr-2" />
                    Earnings
                  </Button>
                  <Button 
                    variant={activeTab === 'settings' ? 'default' : 'ghost'} 
                    className="w-full justify-start" 
                    onClick={() => setActiveTab('settings')}
                  >
                    <Settings size={18} className="mr-2" />
                    Settings
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-50" 
                    onClick={handleLogout}
                  >
                    <LogOut size={18} className="mr-2" />
                    Logout
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="w-full md:w-3/4">
            {activeTab === 'overview' && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Seller Dashboard</CardTitle>
                  <CardDescription>Welcome to your seller control panel.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Total Products</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{mockSellerProducts.length}</div>
                        <p className="text-xs text-muted-foreground">{mockSellerProducts.length} products listed</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Products Sold</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{totalSold}</div>
                        <p className="text-xs text-muted-foreground">Total units sold</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Revenue</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
                        <p className="text-xs text-muted-foreground">Total earnings</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="font-medium mb-3">Recent Orders</h3>
                    <div className="rounded-md border">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left">Order ID</th>
                            <th className="px-4 py-3 text-left">Product</th>
                            <th className="px-4 py-3 text-left">Date</th>
                            <th className="px-4 py-3 text-left">Status</th>
                            <th className="px-4 py-3 text-left">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {mockSellerOrders.slice(0, 3).map((order) => (
                            <tr key={order.id} className="border-b">
                              <td className="px-4 py-3">{order.id}</td>
                              <td className="px-4 py-3">{order.product}</td>
                              <td className="px-4 py-3">{order.date}</td>
                              <td className="px-4 py-3">
                                <span className={`inline-block px-2 py-1 rounded text-xs ${
                                  order.status === 'Delivered' 
                                    ? 'bg-green-100 text-green-800' 
                                    : order.status === 'Shipped' 
                                      ? 'bg-blue-100 text-blue-800' 
                                      : order.status === 'Processing' 
                                        ? 'bg-yellow-100 text-yellow-800' 
                                        : 'bg-gray-100 text-gray-800'
                                }`}>
                                  {order.status}
                                </span>
                              </td>
                              <td className="px-4 py-3">${order.amount.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="mt-3 text-right">
                      <Button variant="outline" size="sm" onClick={() => setActiveTab('orders')}>
                        View All Orders
                      </Button>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="font-medium mb-3">Inventory Status</h3>
                    <div className="rounded-md border">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left">Product</th>
                            <th className="px-4 py-3 text-left">Current Stock</th>
                            <th className="px-4 py-3 text-left">Price</th>
                          </tr>
                        </thead>
                        <tbody>
                          {mockSellerProducts.map((product) => (
                            <tr key={product.id} className="border-b">
                              <td className="px-4 py-3">{product.name}</td>
                              <td className="px-4 py-3">
                                <span className={`inline-block px-2 py-1 rounded text-xs ${
                                  product.stock > 10 
                                    ? 'bg-green-100 text-green-800' 
                                    : product.stock > 0 
                                      ? 'bg-yellow-100 text-yellow-800' 
                                      : 'bg-red-100 text-red-800'
                                }`}>
                                  {product.stock > 0 ? `${product.stock} units` : 'Out of stock'}
                                </span>
                              </td>
                              <td className="px-4 py-3">${product.price.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'products' && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>My Products</CardTitle>
                      <CardDescription>Manage your product listings.</CardDescription>
                    </div>
                    <Button size="sm">
                      <Package size={16} className="mr-2" />
                      Add New Product
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">ID</th>
                          <th className="px-4 py-3">Product Name</th>
                          <th className="px-4 py-3">Price</th>
                          <th className="px-4 py-3">Stock</th>
                          <th className="px-4 py-3">Sold</th>
                          <th className="px-4 py-3">Revenue</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockSellerProducts.map((product) => (
                          <tr key={product.id} className="bg-white border-b">
                            <td className="px-4 py-3">{product.id}</td>
                            <td className="px-4 py-3">{product.name}</td>
                            <td className="px-4 py-3">${product.price.toFixed(2)}</td>
                            <td className="px-4 py-3">{product.stock}</td>
                            <td className="px-4 py-3">{product.sold} units</td>
                            <td className="px-4 py-3">${product.revenue.toFixed(2)}</td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">Edit</Button>
                                <Button variant="outline" size="sm">Restock</Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'orders' && (
              <Card>
                <CardHeader>
                  <CardTitle>My Orders</CardTitle>
                  <CardDescription>View and fulfill customer orders.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">Order ID</th>
                          <th className="px-4 py-3">Customer</th>
                          <th className="px-4 py-3">Product</th>
                          <th className="px-4 py-3">Date</th>
                          <th className="px-4 py-3">Amount</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockSellerOrders.map((order) => (
                          <tr key={order.id} className="bg-white border-b">
                            <td className="px-4 py-3">{order.id}</td>
                            <td className="px-4 py-3">{order.customer}</td>
                            <td className="px-4 py-3">{order.product}</td>
                            <td className="px-4 py-3">{order.date}</td>
                            <td className="px-4 py-3">${order.amount.toFixed(2)}</td>
                            <td className="px-4 py-3">
                              <span className={`inline-block px-2 py-1 rounded text-xs ${
                                order.status === 'Delivered' 
                                  ? 'bg-green-100 text-green-800' 
                                  : order.status === 'Shipped' 
                                    ? 'bg-blue-100 text-blue-800' 
                                    : order.status === 'Processing' 
                                      ? 'bg-yellow-100 text-yellow-800' 
                                      : 'bg-gray-100 text-gray-800'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">Details</Button>
                                {order.status !== 'Delivered' && (
                                  <Button variant="outline" size="sm">Update</Button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'earnings' && (
              <Card>
                <CardHeader>
                  <CardTitle>Earnings</CardTitle>
                  <CardDescription>Track your revenue and payouts.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
                        <p className="text-xs text-muted-foreground">Lifetime earnings</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">$890.50</div>
                        <p className="text-xs text-muted-foreground">Available May 30</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Last Payout</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">$1,250.00</div>
                        <p className="text-xs text-muted-foreground">Received on May 1</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <h3 className="font-medium mb-3">Revenue by Product</h3>
                  <div className="relative overflow-x-auto rounded-md border mb-6">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">Product</th>
                          <th className="px-4 py-3">Units Sold</th>
                          <th className="px-4 py-3">Revenue</th>
                        </tr>
                      </thead>
                      <tbody>
                        {mockSellerProducts.map((product) => (
                          <tr key={product.id} className="bg-white border-b">
                            <td className="px-4 py-3">{product.name}</td>
                            <td className="px-4 py-3">{product.sold}</td>
                            <td className="px-4 py-3">${product.revenue.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  
                  <h3 className="font-medium mb-3">Payout History</h3>
                  <div className="relative overflow-x-auto rounded-md border">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-gray-50 text-gray-700">
                        <tr>
                          <th className="px-4 py-3">Date</th>
                          <th className="px-4 py-3">Amount</th>
                          <th className="px-4 py-3">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="bg-white border-b">
                          <td className="px-4 py-3">May 1, 2023</td>
                          <td className="px-4 py-3">$1,250.00</td>
                          <td className="px-4 py-3">
                            <span className="inline-block px-2 py-1 rounded text-xs bg-green-100 text-green-800">
                              Completed
                            </span>
                          </td>
                        </tr>
                        <tr className="bg-white border-b">
                          <td className="px-4 py-3">Apr 1, 2023</td>
                          <td className="px-4 py-3">$980.75</td>
                          <td className="px-4 py-3">
                            <span className="inline-block px-2 py-1 rounded text-xs bg-green-100 text-green-800">
                              Completed
                            </span>
                          </td>
                        </tr>
                        <tr className="bg-white">
                          <td className="px-4 py-3">Mar 1, 2023</td>
                          <td className="px-4 py-3">$750.25</td>
                          <td className="px-4 py-3">
                            <span className="inline-block px-2 py-1 rounded text-xs bg-green-100 text-green-800">
                              Completed
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'settings' && (
              <Card>
                <CardHeader>
                  <CardTitle>Seller Settings</CardTitle>
                  <CardDescription>Manage your seller account settings.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Business Name</label>
                        <Input defaultValue="My Electronics Shop" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Contact Email</label>
                        <Input defaultValue={userEmail || ''} />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Business Description</label>
                      <textarea 
                        className="w-full min-h-[100px] p-2 border rounded-md" 
                        defaultValue="We sell premium quality electronics products at affordable prices."
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Payment Information</label>
                        <Input type="text" placeholder="Bank account / PayPal" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Tax ID</label>
                        <Input type="text" placeholder="For tax purposes" />
                      </div>
                    </div>
                    
                    <Button>Save Settings</Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default SellerDashboardPage;
