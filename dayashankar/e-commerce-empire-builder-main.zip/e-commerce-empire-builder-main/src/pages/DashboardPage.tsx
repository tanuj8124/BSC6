
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Package, ShoppingCart, Heart, Settings, LogOut } from 'lucide-react';
import { toast } from 'sonner';

const DashboardPage = () => {
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is authenticated
    const isAuth = localStorage.getItem('isAuthenticated');
    const email = localStorage.getItem('userEmail');
    
    if (!isAuth || !email) {
      // Redirect to login if not authenticated
      toast.error('Please login to access your dashboard');
      navigate('/login');
      return;
    }
    
    setUserEmail(email);
    setIsLoading(false);
  }, [navigate]);

  const handleLogout = () => {
    // Clear authentication data
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userEmail');
    
    // Show success message and redirect to login
    toast.success('Successfully logged out');
    navigate('/login');
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-12 flex items-center justify-center">
          <p>Loading your dashboard...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-1/4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User size={20} />
                  <span>My Account</span>
                </CardTitle>
                <CardDescription>
                  {userEmail}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start" onClick={() => navigate('/dashboard')}>
                    <User size={18} className="mr-2" />
                    Dashboard
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => navigate('/orders')}>
                    <Package size={18} className="mr-2" />
                    My Orders
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => navigate('/cart')}>
                    <ShoppingCart size={18} className="mr-2" />
                    My Cart
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => navigate('/wishlist')}>
                    <Heart size={18} className="mr-2" />
                    Wishlist
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={() => navigate('/settings')}>
                    <Settings size={18} className="mr-2" />
                    Account Settings
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-50" onClick={handleLogout}>
                    <LogOut size={18} className="mr-2" />
                    Logout
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="w-full md:w-3/4">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Dashboard</CardTitle>
                <CardDescription>Welcome back! Here's an overview of your account.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Orders</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">0</div>
                      <p className="text-xs text-muted-foreground">No orders yet</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Cart Items</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">0</div>
                      <p className="text-xs text-muted-foreground">Your cart is empty</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Wishlist</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">0</div>
                      <p className="text-xs text-muted-foreground">No items saved</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your recent activities on our platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No recent activities found.
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default DashboardPage;
