
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from '@/components/ui/card';

const AdminLoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('admin');
  const navigate = useNavigate();
  
  // Mock admin and seller accounts
  const mockAdmins = [
    { email: 'admin@example.com', password: 'admin123' },
  ];
  
  const mockSellers = [
    { email: 'seller@example.com', password: 'seller123' },
  ];
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!email || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      let authenticated = false;
      const role = activeTab; // 'admin' or 'seller'
      
      // Check credentials against mock data
      if (role === 'admin') {
        authenticated = mockAdmins.some(
          admin => admin.email === email && admin.password === password
        );
      } else {
        authenticated = mockSellers.some(
          seller => seller.email === email && seller.password === password
        );
      }
      
      if (authenticated) {
        // Store authentication data
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userRole', role);
        
        toast.success(`Login successful as ${role}!`);
        
        // Redirect to appropriate dashboard
        setTimeout(() => {
          navigate(role === 'admin' ? '/admin-dashboard' : '/seller-dashboard');
        }, 500);
      } else {
        toast.error('Invalid credentials. Please try again.');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto">
          <Tabs defaultValue="admin" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="admin">Admin Login</TabsTrigger>
              <TabsTrigger value="seller">Seller Login</TabsTrigger>
            </TabsList>
            
            <Card className="p-6">
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold">
                  {activeTab === 'admin' ? 'Admin Access' : 'Seller Portal'}
                </h1>
                <p className="text-gray-600 mt-2">
                  Sign in to your {activeTab === 'admin' ? 'admin' : 'seller'} account
                </p>
              </div>
              
              <form onSubmit={handleLogin}>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail size={18} className="text-gray-400" />
                      </div>
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        className="pl-10"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                      Password
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock size={18} className="text-gray-400" />
                      </div>
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        className="pl-10 pr-10"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        onClick={toggleShowPassword}
                      >
                        {showPassword ? (
                          <EyeOff size={18} className="text-gray-400" />
                        ) : (
                          <Eye size={18} className="text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <Button type="submit" className="w-full bg-primary" disabled={isLoading}>
                    {isLoading ? 'Signing In...' : `Sign In as ${activeTab === 'admin' ? 'Admin' : 'Seller'}`}
                  </Button>
                </div>
              </form>
              
              {activeTab === 'admin' ? (
                <div className="mt-4 text-sm text-center text-gray-600">
                  <p>Demo credentials:</p>
                  <p className="font-medium">Email: admin@example.com</p>
                  <p className="font-medium">Password: admin123</p>
                </div>
              ) : (
                <div className="mt-4 text-sm text-center text-gray-600">
                  <p>Demo credentials:</p>
                  <p className="font-medium">Email: seller@example.com</p>
                  <p className="font-medium">Password: seller123</p>
                </div>
              )}
            </Card>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
};

export default AdminLoginPage;
