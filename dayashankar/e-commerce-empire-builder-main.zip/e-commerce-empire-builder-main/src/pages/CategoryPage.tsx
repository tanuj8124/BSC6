
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Filter, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MainLayout from '@/components/layout/MainLayout';
import ProductCard from '@/components/product/ProductCard';
import { products } from '@/data/products';
import { Product } from '@/types/product';

const CategoryPage = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortOption, setSortOption] = useState('featured');
  
  // Format the category name for display
  const categoryName = categoryId 
    ? categoryId.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') 
    : 'All Products';
  
  // Filter products by category
  const categoryProducts = categoryId
    ? products.filter(product => 
        product.category.toLowerCase() === categoryId.replace('-', ' ') ||
        product.subcategory?.toLowerCase() === categoryId.replace('-', ' ')
      )
    : products;
  
  // Sort products based on selected option
  const sortedProducts = [...categoryProducts].sort((a, b) => {
    switch (sortOption) {
      case 'price-low-high':
        return a.price - b.price;
      case 'price-high-low':
        return b.price - a.price;
      case 'newest':
        return b.id - a.id;
      case 'rating':
        return b.rating - a.rating;
      default:
        return 0; // featured
    }
  });
  
  const toggleFilters = () => {
    setIsFilterOpen(!isFilterOpen);
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{categoryName}</h1>
          <p className="text-gray-600">
            {sortedProducts.length} products found
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters sidebar - desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <div className="border rounded-lg p-4">
              <h2 className="font-semibold text-lg mb-4 flex items-center">
                <Filter size={16} className="mr-2" />
                Filters
              </h2>
              
              <div className="border-t pt-4 pb-2">
                <h3 className="font-medium mb-3">Price Range</h3>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>Under $50</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>$50 - $100</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>$100 - $200</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>$200 & Above</span>
                  </label>
                </div>
              </div>
              
              <div className="border-t pt-4 pb-2">
                <h3 className="font-medium mb-3">Customer Rating</h3>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>4★ & above</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>3★ & above</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>2★ & above</span>
                  </label>
                </div>
              </div>
              
              <div className="border-t pt-4 pb-2">
                <h3 className="font-medium mb-3">Availability</h3>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" checked readOnly />
                    <span>In Stock</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span>On Sale</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          {/* Product grid with sort */}
          <div className="flex-grow">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              {/* Mobile filter button */}
              <Button 
                variant="outline" 
                className="mb-4 sm:mb-0 md:hidden flex items-center" 
                onClick={toggleFilters}
              >
                <Filter size={16} className="mr-2" />
                Filters
              </Button>
              
              {/* Sort options */}
              <div className="relative w-full sm:w-auto">
                <div className="flex items-center">
                  <span className="text-gray-600 mr-2">Sort by:</span>
                  <select 
                    className="border rounded-md py-2 px-4 pr-8 appearance-none bg-white"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                  >
                    <option value="featured">Featured</option>
                    <option value="price-low-high">Price: Low to High</option>
                    <option value="price-high-low">Price: High to Low</option>
                    <option value="newest">Newest</option>
                    <option value="rating">Top Rated</option>
                  </select>
                  <ChevronDown size={16} className="text-gray-500 -ml-6 pointer-events-none" />
                </div>
              </div>
            </div>
            
            {/* Mobile filters panel */}
            {isFilterOpen && (
              <div className="md:hidden border rounded-lg p-4 mb-6">
                <div className="border-b pb-4 mb-4">
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>Under $50</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>$50 - $100</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>$100 - $200</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>$200 & Above</span>
                    </label>
                  </div>
                </div>
                
                <div className="border-b pb-4 mb-4">
                  <h3 className="font-medium mb-3">Customer Rating</h3>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>4★ & above</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>3★ & above</span>
                    </label>
                  </div>
                </div>
                
                <div className="pb-2">
                  <h3 className="font-medium mb-3">Availability</h3>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" checked readOnly />
                      <span>In Stock</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      <span>On Sale</span>
                    </label>
                  </div>
                </div>
                
                <Button 
                  className="w-full mt-4"
                  onClick={toggleFilters}
                >
                  Apply Filters
                </Button>
              </div>
            )}
            
            {/* Product grid */}
            {sortedProducts.length === 0 ? (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold mb-2">No products found</h2>
                <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4 md:gap-6">
                {sortedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
            
            {/* Pagination - placeholder */}
            <div className="flex justify-center mt-12">
              <nav className="inline-flex">
                <Button variant="outline" className="rounded-l-md" disabled>
                  Previous
                </Button>
                <Button variant="outline" className="border-l-0 rounded-none bg-brand text-white">
                  1
                </Button>
                <Button variant="outline" className="border-l-0 rounded-none">
                  2
                </Button>
                <Button variant="outline" className="border-l-0 rounded-none">
                  3
                </Button>
                <Button variant="outline" className="border-l-0 rounded-r-md">
                  Next
                </Button>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CategoryPage;
