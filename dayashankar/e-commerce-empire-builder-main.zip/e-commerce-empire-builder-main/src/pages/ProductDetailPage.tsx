
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Heart, ShoppingCart, Share2, Check, Star, ChevronRight, Truck, Shield, IndianRupee } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import MainLayout from '@/components/layout/MainLayout';
import { useCart } from '@/contexts/CartContext';
import { products } from '@/data/products';
import { Product } from '@/types/product';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  
  // Find the product by id
  const product = products.find(p => p.id === Number(id));
  
  if (!product) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <p className="mb-6">The product you are looking for does not exist or has been removed.</p>
          <Button asChild>
            <Link to="/">Return to Home</Link>
          </Button>
        </div>
      </MainLayout>
    );
  }
  
  // Convert dollar to rupees (approx rate: 1 USD = 75 INR)
  const priceInRupees = product.price * 75;
  const originalPriceInRupees = product.originalPrice ? product.originalPrice * 75 : undefined;
  
  // Dummy product images for the gallery view
  const productImages = product.images || [
    product.image,
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3',
    'https://images.unsplash.com/photo-1505751171710-1f6d0ace5a85?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3'
  ];
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast.success(`${product.name} added to cart!`);
  };
  
  const handleWishlist = () => {
    toast.success(`${product.name} added to wishlist!`);
  };
  
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Product link copied to clipboard!');
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-gray-500 mb-6">
          <Link to="/" className="hover:text-brand">Home</Link>
          <ChevronRight size={14} className="mx-2" />
          <Link to={`/category/${product.category.toLowerCase()}`} className="hover:text-brand">{product.category}</Link>
          <ChevronRight size={14} className="mx-2" />
          <span className="text-gray-700">{product.name}</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Product images */}
          <div>
            <div className="rounded-lg overflow-hidden mb-4">
              <img 
                src={productImages[selectedImage]} 
                alt={product.name} 
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-2">
              {productImages.map((image, index) => (
                <button 
                  key={index} 
                  className={`border rounded overflow-hidden ${selectedImage === index ? 'border-brand' : 'border-gray-200'}`}
                  onClick={() => setSelectedImage(index)}
                >
                  <img src={image} alt={`${product.name} view ${index + 1}`} className="w-full h-auto" />
                </button>
              ))}
            </div>
          </div>
          
          {/* Product info */}
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    size={16} 
                    className={i < Math.floor(product.rating) ? 'fill-accent2-dark text-accent2-dark' : 'text-gray-300'} 
                  />
                ))}
              </div>
              <span className="text-gray-600 ml-2">{product.rating} ({product.reviewCount} reviews)</span>
            </div>
            
            <div className="mb-6">
              <span className="text-3xl font-bold text-gray-800 flex items-center">
                <IndianRupee size={20} className="mr-1" />
                {priceInRupees.toFixed(2)}
              </span>
              {originalPriceInRupees && (
                <span className="text-gray-500 text-lg line-through ml-3 flex items-center">
                  <IndianRupee size={16} className="mr-0.5" />
                  {originalPriceInRupees.toFixed(2)}
                </span>
              )}
              {product.originalPrice && (
                <span className="text-accent2 ml-3 font-medium">
                  Save ₹{((product.originalPrice - product.price) * 75).toFixed(2)}
                </span>
              )}
            </div>
            
            <p className="text-gray-600 mb-6">
              {product.description || 'This premium product offers exceptional quality and performance. Designed with user comfort and durability in mind, it\'s a perfect addition to your lifestyle.'}
            </p>
            
            <div className="mb-6">
              <div className="flex items-center text-green-600 mb-2">
                <Check size={18} className="mr-2" />
                <span>In Stock - Ready to Ship</span>
              </div>
              
              <div className="flex flex-col mt-4">
                <div className="flex items-center mb-2">
                  <Truck size={16} className="mr-2 text-gray-500" />
                  <span className="text-gray-600">Free delivery on orders over ₹3,750</span>
                </div>
                <div className="flex items-center">
                  <Shield size={16} className="mr-2 text-gray-500" />
                  <span className="text-gray-600">30-day money-back guarantee</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center mb-6">
              <label htmlFor="quantity" className="mr-3 text-gray-700">Quantity:</label>
              <select 
                id="quantity" 
                className="border rounded-md px-3 py-2"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
              >
                {[...Array(10)].map((_, i) => (
                  <option key={i} value={i + 1}>{i + 1}</option>
                ))}
              </select>
            </div>
            
            <div className="flex flex-wrap gap-3 mb-8">
              <Button onClick={handleAddToCart} className="flex-grow" size="lg">
                <ShoppingCart size={18} className="mr-2" />
                Add to Cart
              </Button>
              <Button onClick={handleWishlist} variant="outline" className="flex-grow" size="lg">
                <Heart size={18} className="mr-2" />
                Add to Wishlist
              </Button>
              <Button onClick={handleShare} variant="ghost" size="icon" className="rounded-full h-12 w-12">
                <Share2 size={18} />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Product details tabs */}
        <div className="border-t pt-8">
          <div className="border-b mb-6">
            <div className="flex overflow-x-auto">
              <button className="px-6 py-3 border-b-2 border-brand font-medium text-brand">
                Description
              </button>
              <button className="px-6 py-3 font-medium text-gray-500 hover:text-gray-700">
                Specifications
              </button>
              <button className="px-6 py-3 font-medium text-gray-500 hover:text-gray-700">
                Reviews ({product.reviewCount})
              </button>
            </div>
          </div>
          
          <div className="prose max-w-none">
            <h3 className="text-xl font-semibold mb-4">Product Description</h3>
            <p className="mb-4">
              {product.description || 'Experience unmatched quality with this premium product. Designed with meticulous attention to detail, it combines modern technology with elegant aesthetics.'}
            </p>
            
            {product.features && (
              <>
                <h4 className="font-semibold mt-6 mb-3">Key Features:</h4>
                <ul className="list-disc pl-5 space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ProductDetailPage;
