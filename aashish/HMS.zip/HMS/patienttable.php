<?php
$conn = new mysqli("localhost", "root", "", "hospital_db");
$result = $conn->query("SELECT * FROM patients");

// Check if query successful
if ($result === false) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Records</title>
    <style>
        /* CSS Styling */
        .patient-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: Arial, sans-serif;
        }

        .patient-table th,
        .patient-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .patient-table th {
            background-color: #4CAF50;
            color: white;
        }

        .patient-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .patient-table tr:hover {
            background-color: #ddd;
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .patient-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <table class="patient-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Mobile No</th>
                <th>Problem</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['dob']; ?></td>
                    <td><?php echo $row['gender']; ?></td>
                    <td><?php echo $row['mobile']; ?></td>
                    <td><?php echo $row['problem']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>