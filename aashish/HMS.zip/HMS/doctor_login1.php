<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="login-container">
        <h2>Doctor Login</h2>
        <form id="doctorLoginForm" action="doctor_login.php" method="POST">
            <div class="form-group">
                <label for="mobile">Mobile Number</label>
                <input type="text" id="mobile" name="mobile" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="remember-forgot">
                <a href="forget-password.html">Forgot Password?</a>
            </div>
            <button type="submit">Login</button>
        </form>

        <div class="register-link">
            If you don't have any account <a href="register2.html">Register</a>
         </div>
        <p id="error-message" class="error">
            <?php session_start(); echo isset($_SESSION['error']) ? $_SESSION['error'] : ''; unset($_SESSION['error']); 
            ?>
        </p>
    </div>
    <script src="login.js"></script>
</body>
</html>