document.querySelector('form').addEventListener('submit', function(e) {
    const mobile = document.getElementById('mobile').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorMessage = document.getElementById('error-message');

    if (!mobile || !password) {
        e.preventDefault();
        errorMessage.textContent = 'Please fill in all fields';
        return false;
    }

    if (!/^\d{10}$/.test(mobile)) {
        e.preventDefault();
        errorMessage.textContent = 'Please enter a valid 10-digit mobile number';
        return false;
    }
});