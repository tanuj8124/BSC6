<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['mobile']) || empty($_POST['password'])) {
        $_SESSION['error'] = "Mobile number or password is missing";
        header("Location: admin_login.php");
        exit();
    }

    $mobile = $conn->real_escape_string($_POST['mobile']);
    $password = $_POST['password'];

    // Use prepared statement
    $stmt = $conn->prepare("SELECT * FROM admins WHERE mobile = ?"); // Agar 'users' table use kar rahe ho to 'admins' ki jagah 'users' likho
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['name'] = $admin['name'];
            $_SESSION['mobile'] = $admin['mobile'];
            $_SESSION['role'] = 'admin';
            
            header("Location: admindb.html"); // Admin ka dashboard page
            echo ("logedin successfully!");
            exit();
        } else {
            $_SESSION['error'] = "Invalid password";
        }
    } else {
        $_SESSION['error'] = "Invalid mobile number";
    }
    
    header("Location: admin_login.php");
    exit();
}

$conn->close();
?>