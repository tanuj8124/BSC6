<?php
session_start(); // Session start at the top
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="login-container">
        <h2>Patient Login</h2>
        <form id="patientLoginForm" action="patient_login.php" method="POST">
            <div class="form-group">
                <label for="mobile">Mobile Number</label>
                <input type="text" id="mobile" name="mobile" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="remember-forgot">
                <a href="forget-password.html">Forgot Password?</a>
            </div>
            <button type="submit">Login</button>
        </form>

        <div class="register-link">
            If you don't have any account <a href="register2.html">Register</a>
        </div>
        
        <?php
        // Only show error if it exists
        if (isset($_SESSION['error'])) {
            echo '<p id="error-message" class="error">' . htmlspecialchars($_SESSION['error']) . '</p>';
            unset($_SESSION['error']); // Clear error after displaying
        }
        ?>
    </div>
    <script src="login.js"></script>
</body>
</html>