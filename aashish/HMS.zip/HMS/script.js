document.querySelector('.menu-toggle').addEventListener('click', function() {
    const navLinks = document.querySelector('.nav-links');
    const registerContainer = document.querySelector('.register-container');
    
    navLinks.classList.toggle('active');
    registerContainer.classList.toggle('active');
    
    // Toggle between hamburger and close icon
    this.textContent = navLinks.classList.contains('active') ? '✕' : '☰';
});

// Close mobile menu when clicking outside
document.addEventListener('click', function(event) {
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelector('.nav-links');
    const menuToggle = document.querySelector('.menu-toggle');
    const registerContainer = document.querySelector('.register-container');

    if (!navbar.contains(event.target) && navLinks.classList.contains('active')) {
        navLinks.classList.remove('active');
        registerContainer.classList.remove('active');
        menuToggle.textContent = '☰';
    }
});

// Close mobile menu on resize to desktop size
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        document.querySelector('.nav-links').classList.remove('active');
        document.querySelector('.register-container').classList.remove('active');
        document.querySelector('.menu-toggle').textContent = '☰';
    }
});
