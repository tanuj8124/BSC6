<?php
$host = "localhost";
$username = "root"; // Apna MySQL username
$password = ""; // Apna MySQL password
$database = "hospital_db"; // Apna database name

// Database connection
$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Patients Table Data
$patients_query = "SELECT * FROM patients";
$patients_result = mysqli_query($conn, $patients_query);

echo "<script>";
echo "document.getElementById('patientsTable').innerHTML = '";
while ($row = mysqli_fetch_assoc($patients_result)) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['dob'] . "</td>";
    echo "<td>" . $row['gender'] . "</td>";
    echo "<td>" . $row['mobile'] . "</td>";
    echo "<td>" . $row['problem'] . "</td>";
    echo "<td>" . $row['address'] . "</td>";
    echo "</tr>";
}
echo "';";
echo "</script>";


mysqli_close($conn);
?>