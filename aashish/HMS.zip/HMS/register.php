<?php
// register.php

// Database connection
$server = "localhost";  // MySQL ka address, 3306 port default hoga
$username = "root";
$password = "";
$dbname = "hospital";

$conn = mysqli_connect($server, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check which form section is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Patient Registration
    if (isset($_POST['patient_submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['patient_name']);
        $dob = mysqli_real_escape_string($conn, $_POST['patient_dob']);
        $gender = mysqli_real_escape_string($conn, $_POST['patient_gender']);
        $mobile = mysqli_real_escape_string($conn, $_POST['patient_mobile']);
        $problem = mysqli_real_escape_string($conn, $_POST['patient_problem']);
        $address = mysqli_real_escape_string($conn, $_POST['patient_address']);
        
        $sql = "INSERT INTO patients (name, dob, gender, mobile, problem, address) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$problem', '$address')";
                
        if (mysqli_query($conn, $sql)) {
            echo "Patient registered successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
    
    // Doctor Registration
    if (isset($_POST['doctor_submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['doctor_name']);
        $dob = mysqli_real_escape_string($conn, $_POST['doctor_dob']);
        $gender = mysqli_real_escape_string($conn, $_POST['doctor_gender']);
        $mobile = mysqli_real_escape_string($conn, $_POST['doctor_mobile']);
        $specialization = mysqli_real_escape_string($conn, $_POST['doctor_specialization']);
        $experience = mysqli_real_escape_string($conn, $_POST['doctor_experience']);
        
        $sql = "INSERT INTO doctors (name, dob, gender, mobile, specialization, experience) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$specialization', '$experience')";
                
        if (mysqli_query($conn, $sql)) {
            echo "Doctor registered successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
    
    // Nurse Registration
    if (isset($_POST['nurse_submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['nurse_name']);
        $dob = mysqli_real_escape_string($conn, $_POST['nurse_dob']);
        $gender = mysqli_real_escape_string($conn, $_POST['nurse_gender']);
        $mobile = mysqli_real_escape_string($conn, $_POST['nurse_mobile']);
        $qualification = mysqli_real_escape_string($conn, $_POST['nurse_qualification']);
        $experience = mysqli_real_escape_string($conn, $_POST['nurse_experience']);
        
        $sql = "INSERT INTO nurses (name, dob, gender, mobile, qualification, experience) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$qualification', '$experience')";
                
        if (mysqli_query($conn, $sql)) {
            echo "Nurse registered successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>