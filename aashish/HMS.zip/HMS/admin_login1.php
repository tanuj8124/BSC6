<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beautiful Login Page</title>
    <style>
       
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(35deg,rgb(26, 1, 255),rgb(52, 197, 255));
        }

        .container {
            position: relative;
            width: 100%;
            max-width: 400px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4);
            margin: 20px;
        }

        .login-box {
            position: relative;
            width: 100%;
        }

        .login-box h2 {
            color: #fff;
            text-align: center;
            margin-bottom: 40px;
            font-size: 2em;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .input-box {
            position: relative;
            margin-bottom: 35px;
        }

        .input-box input {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.2);
            border: none;
            outline: none;
            border-radius: 25px;
            font-size: 1em;
            color:rgb(255, 255, 255);
            transition: 0.3s;
        }

        .input-box label {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
            pointer-events: none;
            transition: 0.3s;
        }

        .input-box input:focus ~ label,
        .input-box input:valid ~ label {
            top: -5px;
            left: 10px;
            font-size: 0.8em;
            background: transparent;
            padding: 0 5px;
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            margin-bottom: 25px;
            color: #fff;
            font-size: 0.9em;
        }

        .remember-forgot a {
            color: #fff;
            text-decoration: none;
        }

        .remember-forgot a:hover {
            text-decoration: underline;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: #fff;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-btn:hover {
            background: #f0f0f0;
            transform: translateY(-2px);
        }
        
        .register-link {
            color: #fff;
            text-align: center;
            margin-top: 20px;
        }
        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }

            .login-box h2 {
                font-size: 1.5em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h2>Admin Login</h2>
            <?php
            session_start();
            if (isset($_SESSION['error'])) {
                echo '<p style="color: red; text-align: center;">' . $_SESSION['error'] . '</p>';
                unset($_SESSION['error']);
            }
            ?>
            <form action="admin_login.php" method="post">
                <div class="input-box">
                    <input type="text" name="mobile" required>
                    <label>Mobile Number</label>
                </div>
                <div class="input-box">
                    <input type="password" name="password" required>
                    <label>Password</label>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox" name="remember"> Remember me</label>
                    <a href="forget-password.html">Forgot Password?</a>
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>
            <div class="register-link">
                Contact administrator for account creation
            </div>
        </div>
    </div>
</body>
</html>