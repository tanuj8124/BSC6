-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 09:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `mobile`, `password`, `role`) VALUES
(1, 'Admin', '1234567890', '$2y$10$cNpUNoKHhLERpwad31C75.eDTNHc2z9Dq39g7rei19S.f9x3q4/ia', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `patient_name` varchar(255) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `doctor` varchar(255) NOT NULL,
  `appointment_date` date NOT NULL,
  `time_slot` varchar(50) NOT NULL,
  `problem` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`patient_name`, `contact_no`, `doctor`, `appointment_date`, `time_slot`, `problem`, `created_at`) VALUES
('Raj verma', '9867654543', 'Dr. Singh - Pediatrician', '2025-06-02', '09:00 AM', 'Back pain', '2025-05-04 12:44:07');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `experience` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `dob`, `gender`, `mobile`, `specialization`, `experience`, `password`) VALUES
(2, 'Dr. Meera sharma', '1990-01-12', 'Female', '7654343212', 'Gynacologist', 4, '$2y$10$BkpNh2XIXAm6ENry2yNrbeNm/FWTkOqoIPt0.1M4sUw3csnQP7NGO'),
(3, 'Dr. Kavya gupta', '1998-08-04', 'Female', '9012323456', 'Gynacologist', 3, '$2y$10$EzOfM/yrJysdek4jyo5j..sFm8wKUQpSwvmkLG1mdW8S0p/YETE.m'),
(4, 'Dr. Kunal patel', '1995-05-13', 'Male', '8967452312', 'Orthopedic', 4, '$2y$10$grGN0aNubHbC9qV7r5dX/eAGKlgyN2ngyNfaXoH4hHRpkSPa36dxa'),
(5, 'Dr. Riya singh', '1989-09-03', 'Female', '6234566534', 'Orthopedic', 5, '$2y$10$.L7vsrdmsrAVAIUe1zAILuOvEbG2fiUrdxNIBy6eBQdbViZTqqVqi'),
(6, 'Dr. Nandini reddy', '1996-07-06', 'Female', '6234769809', 'Dermatologist', 3, '$2y$10$SP7RJeh1sCh1.PMpdhmlNenJfVuA063sl09eRrSGHQvKkHbNqzw9e'),
(7, 'Dr. Kabir khan', '1992-12-09', 'Male', '6465870912', 'Dermatologist', 4, '$2y$10$AOVvzytyzOWLX0g1GIcZmO3ZRJDqvfbi5c9HIoH6n6pC3FA3NlOVe');

-- --------------------------------------------------------

--
-- Table structure for table `nurses`
--

CREATE TABLE `nurses` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `experience` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nurses`
--

INSERT INTO `nurses` (`id`, `name`, `dob`, `gender`, `mobile`, `qualification`, `experience`, `password`) VALUES
(101, 'Rahul', '2003-04-02', 'Male', '9087654321', 'B.Sc.(nursing)', 2, '$2y$10$iTiqkvflEsufPmLjs86CP./lJWLHt2Pt14lW8kCS8UHquKgSu1hgu'),
(102, 'Diya singh', '1996-02-28', 'Female', '6263646566', 'B.Sc.(Nursing)', 4, '$2y$10$CYvtDfWMbADfRSW0fqYQ..Wju7jAOE1av7LwPXGyiMheSsNV0gsP6');

-- --------------------------------------------------------

--
-- Table structure for table `operation`
--

CREATE TABLE `operation` (
  `patient_name` varchar(50) DEFAULT NULL,
  `operation_time` time DEFAULT NULL,
  `operation_date` date DEFAULT NULL,
  `operation_type` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `problem` text NOT NULL,
  `address` text NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `dob`, `gender`, `mobile`, `problem`, `address`, `password`) VALUES
(101, 'Rahul sharma', '1990-01-15', 'Male', '9876543101', 'knee injury', '12, Civil line, Raipur, CG', '$2y$10$wWQvuWP0myoi/P7NfiQac.v67Msflio3D7uXM1LJ5awbJtmK3m7Cq'),
(102, 'Priya singh', '1999-12-22', 'Female', '8765432109', 'menstrual irregularity', '45, Shanti nagar, Bilaspur, CG', '$2y$10$kM3o2Arq4ug/92bkpXM5guNaYoDtMfTaKIfi1lfScc4MD.pNBu4W6'),
(103, 'Amit kumar', '1995-01-10', 'Male', '7654321098', 'acne', '78, Sadar bazar, Durg, CG', '$2y$10$J4cJ.hrW2FzADGH75yb4ue4GLV50tJa6HPmrzRZt6KgSIh6Wt6WEm'),
(104, 'Sneha patel', '1998-07-18', 'Female', '6243211098', 'back pain', '19, Pamdri, Raipur, CG', '$2y$10$iM7bVdkMHD51aFc6mNrpZ.9u29tZDFjxdWcbvbIPmGrYMaGvyD0iu'),
(105, 'Rohit verma', '1993-11-05', 'Male', '6210987654', 'shoulder dislocation', '19, Nehru nagar, Korba, CG\r\n', '$2y$10$TyKNktWoRVlnC2izOgPgmOqoALym9p/zc1rUfLJKrB11SFQGcRXNS'),
(106, 'Vikram Yadav', '1988-09-25', 'Male', '6432109876', 'Back pain', '14, Ashok Nagar, Bhilai, CG', '$2y$10$bF.I2J0f2uimN4OiZyoLdOpWLS2485qNTrAPwcNquwKAt1xP7gBaS'),
(107, 'Anjali Gupta', '1998-01-30', 'Female', '7321098765', 'Polycystic ovary syndrome', '102, Telibandha, Raipur, CG', '$2y$10$yqNPN/gyIs2eArqHfFnfG.1dfxBG09rcCi07o1LphZ.mKRlJqI8ri'),
(108, 'Kavita Joshi', '1987-04-12', 'Female', '8109876543', 'Skin rash', '40, Vidhan Sabha Road, raipur, CG', '$2y$10$COxwJfs0eeHKGYBSnOrbPeKdBhnWDa62O9DKtCDPPLyvxudJJk8kK'),
(109, 'Suresh Nair', '1991-06-20', 'Male', '9098765432', 'Fractured ankle', '35, Station colony, durg, CG', '$2y$10$PO9Xw7CVKASmSNbIswY0y.KltHyE6TkMVMbhzExPxCCfolC9KTTOC'),
(110, 'Neha Reddy', '1996-08-08', 'Female', '9988776655', 'Dermatitis', '25, Santosi nagar, korba, CG', '$2y$10$.iFNtQmAt8Yv69kCTW02kuWjmHvv8INaHkDF5zbHqYEzePYQxLqYa'),
(111, 'Arjun Mehra', '1989-02-14', 'Male', '8877665544', 'Joint stiffness', '66, gandhi chok, janjgir, CG', '$2y$10$L50qnFeYv2W7Nw5L5SuN6uZV1Q90Vg.IhVs5AvhMQ1dxWN8XgPzUi'),
(112, 'Pooja Desai', '1994-10-28', 'Female', '7766554433', 'Endometriosis', '14, Agrasen chok, mungeli, CG', '$2y$10$5zwdsYPaJMVAseCX8LtDw.adBufFXusRz2Nfvl.Pon3y4ZJ4XwpTS'),
(113, 'Manish Tiwari', '1990-12-03', 'Male', '6655443322', 'Psoriasis', '20, budhwari chok, baloda bazar, CG', '$2y$10$SnTTPKfkqDEivNxGKwf65un3KsNPm1DL2oEfbUanAoM/T7WvHeN7G'),
(114, 'Raj verma', '1990-01-06', 'Male', '6554433221', 'back pain', '12, Gandhi nagar, Janjgir, CG', '$2y$10$dX3QWN/H3WDf.UO7l1vZCeQiG1Sh4Wjcgt6VtrZujRpvxYNtC2lcK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nurses`
--
ALTER TABLE `nurses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nurses`
--
ALTER TABLE `nurses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
