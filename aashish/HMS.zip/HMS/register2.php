<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Register Patient
if (isset($_POST['register_patient'])) {
    $name = $_POST['patient_name'];
    $dob = $_POST['patient_dob'];
    $gender = $_POST['patient_gender'];
    $mobile = $_POST['patient_mobile'];
    $problem = $_POST['patient_problem'];
    $address = $_POST['patient_address'];
    $password = $_POST['patient_password'];
    $confirm_password = $_POST['patient_confirm_password'];

    if ($password === $confirm_password) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO patients (name, dob, gender, mobile, problem, address, password) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$problem', '$address', '$password_hash')";
        if ($conn->query($sql) === TRUE) {
            echo "Patient registered successfully!";
            header("location:index.html");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Passwords do not match!";
    }
}

// Register Doctor
if (isset($_POST['register_doctor'])) {
    $name = $_POST['doctor_name'];
    $dob = $_POST['doctor_dob'];
    $gender = $_POST['doctor_gender'];
    $mobile = $_POST['doctor_mobile'];
    $specialization = $_POST['doctor_specialization'];
    $experience = $_POST['doctor_experience'];
    $password = $_POST['doctor_password'];
    $confirm_password = $_POST['doctor_confirm_password'];

    if ($password === $confirm_password) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO doctors (name, dob, gender, mobile, specialization, experience, password) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$specialization', '$experience', '$password_hash')";
        if ($conn->query($sql) === TRUE) {
            echo "Doctor registered successfully!";
            header("location:index.html");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Passwords do not match!";
    }
}

// Register Nurse
if (isset($_POST['register_nurse'])) {
    $name = $_POST['nurse_name'];
    $dob = $_POST['nurse_dob'];
    $gender = $_POST['nurse_gender'];
    $mobile = $_POST['nurse_mobile'];
    $qualification = $_POST['nurse_qualification'];
    $experience = $_POST['nurse_experience'];
    $password = $_POST['nurse_password'];
    $confirm_password = $_POST['nurse_confirm_password'];

    if ($password === $confirm_password) {
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO nurses (name, dob, gender, mobile, qualification, experience, password) 
                VALUES ('$name', '$dob', '$gender', '$mobile', '$qualification', '$experience', '$password_hash')";
        if ($conn->query($sql) === TRUE) {
            echo "Nurse registered successfully!";
            header("location:index.html");
        }
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Passwords do not match!";
    }
}

$conn->close();
?>
