<?php
// Ensure no output before this
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_db";

// Database connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if POST data exists
    if (empty($_POST['mobile']) || empty($_POST['password'])) {
        $_SESSION['error'] = "Mobile number or password is missing";
        header("Location: nurse_login.php");
        exit();
    }

    $mobile = $conn->real_escape_string($_POST['mobile']);
    $password = $_POST['password'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM nurses WHERE mobile = ?");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $nurse = $result->fetch_assoc();
        // Verify hashed password
        if (password_verify($password, $nurse['password'])) {
            $_SESSION['nurse_id'] = $nurse['id'];
            $_SESSION['name'] = $nurse['name'];
            $_SESSION['mobile'] = $nurse['mobile'];
            $_SESSION['role'] = 'nurse';
            header("Location: nursedb.html"); // Yahan nurse-specific dashboard daal sakte ho
            exit();
        } else {
            $_SESSION['error'] = "Invalid password";
        }
    } else {
        $_SESSION['error'] = "Invalid mobile number";
    }
    
    header("Location: nurse_login.php");
    exit();
}

$conn->close();
?>