function showForm(section) {
    // Hide all sections
    document.getElementById('patient-form').style.display = 'none';
    document.getElementById('doctor-form').style.display = 'none';
    document.getElementById('nurse-form').style.display = 'none';

    // Show the selected form section
    if (section === 'patient') {
        document.getElementById('patient-form').style.display = 'block';
    } else if (section === 'doctor') {
        document.getElementById('doctor-form').style.display = 'block';
    } else if (section === 'nurse') {
        document.getElementById('nurse-form').style.display = 'block';
    }
}
