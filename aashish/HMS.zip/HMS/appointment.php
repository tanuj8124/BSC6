<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "hospital_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data
$patient_name = $_POST['patientName'];
$contact_no = $_POST['contactNo'];
$doctor = $_POST['doctor'];
$appointment_date = $_POST['date'];
$time_slot = $_POST['timeSlot'];
$problem = $_POST['problem'];

// Validate input
if (empty($patient_name) || empty($contact_no) || empty($doctor) || empty($appointment_date) || empty($time_slot) || empty($problem)) {
    $message = "All fields are required.";
    header("Location: appointment.html?message=" . urlencode($message));
    exit;
}

// Validate contact number
if (!preg_match('/^[0-9]{10}$/', $contact_no)) {
    $message = "Invalid contact number.";
    header("Location: appointment.html?message=" . urlencode($message));
    exit;
}

// Check if time slot is already booked
$sql = "SELECT COUNT(*) as count FROM appointments WHERE doctor = '$doctor' AND appointment_date = '$appointment_date' AND time_slot = '$time_slot'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['count'] > 0) {
    $message = "Time slot already booked.";
    header("Location: index.html?message=" . urlencode($message));
    exit;
}

// Insert data into database
$sql = "INSERT INTO appointments (patient_name, contact_no, doctor, appointment_date, time_slot, problem)
        VALUES ('$patient_name', '$contact_no', '$doctor', '$appointment_date', '$time_slot', '$problem')";

if (mysqli_query($conn, $sql)) {
    $message = "Appointment booked successfully!";
} else {
    $message = "Error: " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);

// Redirect back to form with message
header("Location: index.html?message=" . urlencode($message));
exit;
?>