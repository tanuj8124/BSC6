#ifndef FILE_HANDLER_H_
#define FILE_HANDLER_H_

char* load_file_into_memory(const char *path);

#endif // !FILE_HANDLER_H_
;
