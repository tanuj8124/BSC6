
import React, { createContext, useState, useContext, ReactNode, useEffect } from "react";
import { Item, ItemStatus, SearchFilters, User, SiteSetting } from "@/types";
import { getCurrentUser, items as mockItems } from "@/services/mockData";
import { v4 as uuidv4 } from "uuid";
import { toast } from "@/components/ui/use-toast";
import { supabase, checkIsAdmin } from "@/integrations/supabase/client";

interface AppContextType {
  items: Item[];
  filteredItems: Item[];
  currentUser: User | null;
  filters: SearchFilters;
  addItem: (item: Omit<Item, "id" | "userId" | "createdAt">) => void;
  updateItem: (id: string, updates: Partial<Item>) => void;
  deleteItem: (id: string) => void;
  updateFilters: (newFilters: Partial<SearchFilters>) => void;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  isAuthenticated: boolean;
  isAdmin: boolean;
  registerUser: (name: string, email: string, password: string) => Promise<boolean>;
  registeredUsers: RegisteredUser[];
  siteSettings: Record<string, any>;
  updateSiteSetting: (key: string, value: any) => Promise<boolean>;
  cleanupAuthState: () => void;
}

interface RegisteredUser {
  id: string;
  name: string;
  email: string;
  password: string;
}

const initialFilters: SearchFilters = {
  query: "",
  status: "all",
  category: "all",
  date: null,
  location: "all",
};

const AppContext = createContext<AppContextType | undefined>(undefined);

// Local storage key for registered users
const REGISTERED_USERS_STORAGE_KEY = "registered_users";

// Helper function to clean up auth state
const cleanupAuthState = () => {
  // Remove standard auth tokens
  localStorage.removeItem('supabase.auth.token');
  
  // Remove all Supabase auth keys from localStorage
  Object.keys(localStorage).forEach((key) => {
    if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
      localStorage.removeItem(key);
    }
  });
  
  // Remove from sessionStorage if in use
  Object.keys(sessionStorage || {}).forEach((key) => {
    if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
      sessionStorage.removeItem(key);
    }
  });
};

// Demo account credentials
const demoAccounts = [
  { email: "user@example.com", password: "user123", name: "Demo User", role: "user" },
  { email: "admin@example.com", password: "admin123", name: "Demo Admin", role: "admin" }
];

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<Item[]>(mockItems);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [filters, setFilters] = useState<SearchFilters>(initialFilters);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>([]);
  const [siteSettings, setSiteSettings] = useState<Record<string, any>>({});

  // Load registered users from local storage on initialization
  useEffect(() => {
    const storedUsers = localStorage.getItem(REGISTERED_USERS_STORAGE_KEY);
    if (storedUsers) {
      setRegisteredUsers(JSON.parse(storedUsers));
    }
    
    // Setup auth listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session) {
          const userData = {
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata.name || session.user.email?.split('@')[0] || 'User',
            role: 'user' as const
          };
          
          setCurrentUser(userData);
          setIsAuthenticated(true);
          
          // Check if user is admin (defer to prevent lock)
          setTimeout(async () => {
            const adminStatus = await checkIsAdmin();
            setIsAdmin(adminStatus);
            
            if (adminStatus) {
              setCurrentUser(prev => prev ? { ...prev, role: 'admin' } : prev);
            }
          }, 0);
        } else if (event === 'SIGNED_OUT') {
          setCurrentUser(null);
          setIsAuthenticated(false);
          setIsAdmin(false);
        }
      }
    );
    
    // Check initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        const userData = {
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata.name || session.user.email?.split('@')[0] || 'User',
          role: 'user' as const
        };
        
        setCurrentUser(userData);
        setIsAuthenticated(true);
        
        // Check if user is admin
        checkIsAdmin().then(adminStatus => {
          setIsAdmin(adminStatus);
          
          if (adminStatus) {
            setCurrentUser(prev => prev ? { ...prev, role: 'admin' } : prev);
          }
        });
      }
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Save registered users to local storage whenever it changes
  useEffect(() => {
    if (registeredUsers.length > 0) {
      localStorage.setItem(REGISTERED_USERS_STORAGE_KEY, JSON.stringify(registeredUsers));
    }
  }, [registeredUsers]);

  // Apply filters to items
  const filteredItems = items.filter((item) => {
    const matchesQuery =
      filters.query === "" ||
      item.title.toLowerCase().includes(filters.query.toLowerCase()) ||
      item.description.toLowerCase().includes(filters.query.toLowerCase());

    // Status filter
    const matchesStatus = filters.status === "all" || item.status === filters.status;

    // Category filter
    const matchesCategory = filters.category === "all" || item.category === filters.category;

    // Location filter
    const matchesLocation = filters.location === "all" || item.location === filters.location;

    // Date filter
    const matchesDate = !filters.date || item.date === filters.date;

    return matchesQuery && matchesStatus && matchesCategory && matchesLocation && matchesDate;
  });

  const addItem = (itemData: Omit<Item, "id" | "userId" | "createdAt">) => {
    if (!currentUser) {
      toast({
        title: "Authentication Required",
        description: "Please log in to submit an item.",
        variant: "destructive",
      });
      return;
    }

    const newItem: Item = {
      ...itemData,
      id: uuidv4(),
      userId: currentUser.id,
      createdAt: new Date().toISOString(),
    };

    setItems([newItem, ...items]);
    toast({
      title: "Item successfully added",
      description: `Your ${itemData.status} item has been posted.`,
    });
  };

  const updateItem = (id: string, updates: Partial<Item>) => {
    setItems(
      items.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
    toast({
      title: "Item updated",
      description: "The item has been successfully updated.",
    });
  };

  const deleteItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
    toast({
      title: "Item deleted",
      description: "The item has been removed from the listings.",
    });
  };

  const updateFilters = (newFilters: Partial<SearchFilters>) => {
    setFilters({ ...filters, ...newFilters });
  };

  // Register new user using Supabase
  const registerUser = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      // Clean up existing auth state
      cleanupAuthState();
      
      // Check if this is a demo account
      const isDemoEmail = demoAccounts.some(account => account.email.toLowerCase() === email.toLowerCase());
      
      if (isDemoEmail) {
        toast({
          title: "Registration failed",
          description: "This email is already registered as a demo account. Please use a different email.",
          variant: "destructive",
        });
        return false;
      }
      
      // Try to sign out globally if already logged in
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (err) {
        // Continue even if this fails
      }
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          }
        }
      });
      
      if (error) throw error;
      
      toast({
        title: "Registration successful",
        description: "Your account has been created. Please check your email for verification.",
      });
      
      return true;
    } catch (error: any) {
      console.error('Registration error:', error);
      toast({
        title: "Registration failed",
        description: error.message || "An error occurred during registration.",
        variant: "destructive",
      });
      return false;
    }
  };

  // Login with Supabase or demo accounts
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Clean up existing auth state
      cleanupAuthState();
      
      // Check if this is a demo account
      const demoAccount = demoAccounts.find(
        account => account.email.toLowerCase() === email.toLowerCase() && 
                  account.password === password
      );
      
      if (demoAccount) {
        // Mock successful login for demo accounts
        const userData: User = {
          id: `demo-${demoAccount.email}`,
          email: demoAccount.email,
          name: demoAccount.name,
          role: demoAccount.role as 'user' | 'admin'
        };
        
        setCurrentUser(userData);
        setIsAuthenticated(true);
        setIsAdmin(demoAccount.role === 'admin');
        
        toast({
          title: "Welcome to demo mode",
          description: `You've logged in as a demo ${demoAccount.role}.`,
        });
        
        return true;
      }
      
      // Try to sign out globally if already logged in
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (err) {
        // Continue even if this fails
      }
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) throw error;
      
      toast({
        title: "Welcome back",
        description: `You've successfully logged in.`,
      });
      
      return true;
    } catch (error: any) {
      console.error('Login error:', error);
      
      // Special handling for email not confirmed error
      if (error?.value?.code === "email_not_confirmed") {
        // Let this error be handled by the login component
        throw error;
      }
      
      // Check if the error is because the user doesn't exist
      if (error.message?.includes("Invalid login credentials")) {
        toast({
          title: "Login failed",
          description: "Invalid email or password. Please try again.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Login failed",
          description: error.message || "An error occurred during login.",
          variant: "destructive",
        });
      }
      
      return false;
    }
  };

  // Logout with Supabase
  const logout = async () => {
    try {
      // Clean up auth state
      cleanupAuthState();
      
      // For demo accounts just reset the state
      if (currentUser?.id.startsWith('demo-')) {
        setCurrentUser(null);
        setIsAuthenticated(false);
        setIsAdmin(false);
        
        toast({
          title: "Logged out",
          description: "You've been successfully logged out from demo mode.",
        });
        return;
      }
      
      // Attempt sign out
      await supabase.auth.signOut({ scope: 'global' });
      
      setCurrentUser(null);
      setIsAuthenticated(false);
      setIsAdmin(false);
      
      toast({
        title: "Logged out",
        description: "You've been successfully logged out.",
      });
    } catch (error: any) {
      console.error('Logout error:', error);
      toast({
        title: "Logout error",
        description: error.message || "An error occurred during logout.",
        variant: "destructive",
      });
    }
  };

  // Update site settings
  const updateSiteSetting = async (key: string, value: any): Promise<boolean> => {
    try {
      if (!isAdmin) {
        toast({
          title: "Permission denied",
          description: "Only admins can update site settings.",
          variant: "destructive",
        });
        return false;
      }
      
      // Mock update - in a real app, this would call an API
      setSiteSettings(prev => ({
        ...prev,
        [key]: value
      }));
      
      toast({
        title: "Settings updated",
        description: `The ${key} settings have been updated successfully.`,
      });
      
      return true;
    } catch (error) {
      console.error(`Error updating ${key} settings:`, error);
      toast({
        title: "Failed to update settings",
        description: "An error occurred while updating the settings.",
        variant: "destructive",
      });
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        items,
        filteredItems,
        currentUser,
        filters,
        addItem,
        updateItem,
        deleteItem,
        updateFilters,
        login,
        logout,
        isAuthenticated,
        isAdmin,
        registerUser,
        registeredUsers,
        siteSettings,
        updateSiteSetting,
        cleanupAuthState,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
