import { Item, ItemCategory, ItemStatus, User } from "@/types";
import { v4 as uuidv4 } from "uuid";

// Mock users
export const users: User[] = [
  {
    id: "user-1",
    name: "Alex Johnson",
    email: "alex@university.edu",
    role: "user",
  },
  {
    id: "user-2",
    name: "Jamie Smith",
    email: "jamie@university.edu",
    role: "user",
  },
  {
    id: "admin-1",
    name: "Admin User",
    email: "admin@university.edu",
    role: "admin",
  },
];

// Mock campus locations
export const campusLocations = [
  "Main Library",
  "Student Center",
  "Science Building",
  "Engineering Hall",
  "Arts & Humanities",
  "Dining Hall",
  "Recreation Center",
  "Computer Lab",
  "Dormitory A",
  "Dormitory B",
  "Parking Lot",
  "Campus Shuttle",
  "Administration Building",
];

// Mock items
export const items: Item[] = [
  {
    id: uuidv4(),
    title: "Silver MacBook Pro",
    description: "13-inch MacBook Pro with stickers on the cover, left in the library study room 204.",
    category: "electronics",
    status: "found",
    location: "Main Library",
    date: "2025-04-25",
    imageUrl: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=500",
    contactEmail: "jamie@university.edu",
    contactPhone: "555-123-4567",
    userId: "user-2",
    createdAt: "2025-05-01T14:32:00Z",
  },
  {
    id: uuidv4(),
    title: "Student ID Card",
    description: "Lost my student ID card somewhere near the cafeteria. Name on card: Alex Johnson",
    category: "documents",
    status: "lost",
    location: "Dining Hall",
    date: "2025-04-30",
    imageUrl: "https://images.unsplash.com/photo-1473186505569-9c61870c11f9?q=80&w=500",
    contactEmail: "alex@university.edu",
    contactPhone: "555-987-6543",
    userId: "user-1",
    createdAt: "2025-04-30T16:45:00Z",
  },
  {
    id: uuidv4(),
    title: "Blue Hydro Flask Water Bottle",
    description: "Lost my 32oz blue Hydro Flask water bottle with university stickers around the Recreation Center.",
    category: "other",
    status: "lost",
    location: "Recreation Center",
    date: "2025-05-02",
    imageUrl: "/lovable-uploads/cd9b6395-eb8b-43d1-afbd-ee33a25aacf2.png",
    contactEmail: "alex@university.edu",
    contactPhone: "555-987-6543",
    userId: "user-1",
    createdAt: "2025-05-02T09:15:00Z",
  },
  {
    id: uuidv4(),
    title: "Blue Mountain Bike",
    description: "Found a blue mountain bike locked to the bike rack outside the Science Building. Looking for the owner.",
    category: "other",
    status: "found",
    location: "Science Building",
    date: "2025-05-01",
    imageUrl: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?q=80&w=500",
    contactEmail: "jamie@university.edu",
    contactPhone: "555-123-4567",
    userId: "user-2", 
    createdAt: "2025-05-01T18:20:00Z",
  },
  {
    id: uuidv4(),
    title: "Gray North Face Backpack",
    description: "Found a gray North Face backpack containing some textbooks in the Engineering building, room 105.",
    category: "accessories",
    status: "found",
    location: "Engineering Hall",
    date: "2025-04-29",
    imageUrl: "https://images.unsplash.com/photo-1577733966973-d680bffd2e80?q=80&w=500",
    contactEmail: "admin@university.edu",
    contactPhone: "555-000-1234",
    userId: "admin-1",
    createdAt: "2025-04-29T17:10:00Z",
  },
  {
    id: uuidv4(),
    title: "Physics Textbook",
    description: "Lost my Physics 101 textbook, possibly in the Science building or library.",
    category: "books",
    status: "lost",
    location: "Science Building",
    date: "2025-04-26",
    imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=500",
    contactEmail: "alex@university.edu",
    contactPhone: "555-987-6543",
    userId: "user-1",
    createdAt: "2025-04-27T08:30:00Z",
  },
  {
    id: uuidv4(),
    title: "Gold Earrings",
    description: "Found a pair of gold hoop earrings in the women's restroom of the Arts & Humanities building.",
    category: "accessories",
    status: "found",
    location: "Arts & Humanities",
    date: "2025-05-03",
    imageUrl: "/lovable-uploads/7a0b19e9-70c6-405f-8e22-e3d584432d36.png",
    contactEmail: "admin@university.edu",
    contactPhone: "555-000-1234",
    userId: "admin-1",
    createdAt: "2025-05-03T14:45:00Z",
  },
];

// Categories with their display names and icons
export const categoryInfo: Record<ItemCategory | 'all', { label: string, icon: string }> = {
  all: { label: "All Categories", icon: "layers" },
  electronics: { label: "Electronics", icon: "laptop" },
  clothing: { label: "Clothing", icon: "shirt" },
  accessories: { label: "Accessories", icon: "backpack" },
  books: { label: "Books", icon: "book" },
  documents: { label: "Documents", icon: "file-text" },
  keys: { label: "Keys", icon: "key" },
  other: { label: "Other", icon: "more-horizontal" },
};

// Status with their display names and colors
export const statusInfo: Record<ItemStatus | 'all', { label: string, color: string, icon: string }> = {
  all: { label: "All Items", color: "gray", icon: "layers" },
  lost: { label: "Lost", color: "red", icon: "search" },
  found: { label: "Found", color: "green", icon: "check" },
  claimed: { label: "Claimed", color: "blue", icon: "check-circle" },
};

// Helper function to get a mock user
export const getCurrentUser = (): User => {
  return users[0];
};
