
export type ItemStatus = "lost" | "found" | "claimed";

export type ItemCategory = 
  | "electronics" 
  | "clothing" 
  | "accessories" 
  | "books" 
  | "documents" 
  | "keys" 
  | "other";

export interface Item {
  id: string;
  title: string;
  description: string;
  category: ItemCategory;
  status: ItemStatus;
  location: string;
  date: string;
  imageUrl: string;
  contactEmail: string;
  contactPhone: string;
  userId: string;
  createdAt: string;
}

export interface ItemFormData extends Omit<Item, "id" | "userId" | "createdAt"> {
  imageFile?: File | null;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: "user" | "admin";
}

export interface SearchFilters {
  query: string;
  status: ItemStatus | "all";
  category: ItemCategory | "all";
  date: string | null;
  location: string | "all";
}

export interface SiteTheme {
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;
}

export interface HomepageContent {
  heroTitle: string;
  heroSubtitle: string;
  featuredItems: number;
}

export interface FeaturesConfig {
  enableSearch: boolean;
  enableNotifications: boolean;
  enableLocationTracking: boolean;
}

export interface SiteSetting {
  id: string;
  setting_key: string;
  setting_value: SiteTheme | HomepageContent | FeaturesConfig;
  updated_at: string;
  updated_by?: string;
}
