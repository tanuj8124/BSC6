
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Search, Upload } from "lucide-react";

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 hero-pattern">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Lost Something on Campus?
              </h1>
              <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                Quickly report lost or found items. Our campus lost & found platform helps reconnect people with their belongings.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 min-[400px]:flex-row">
              <Link to="/search">
                <Button className="gap-1">
                  <Search className="h-4 w-4" />
                  Find Lost Items
                </Button>
              </Link>
              <Link to="/new-item">
                <Button variant="outline" className="gap-1">
                  <Upload className="h-4 w-4" />
                  Report Found Item
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full">
              <img
                alt="University campus entrance"
                className="mx-auto aspect-video h-auto w-full max-w-full rounded-lg object-cover shadow-md sm:w-10/12 md:w-9/12 lg:w-full"
                src="/lovable-uploads/fb2c0531-8f11-419a-955a-e03c23021204.png"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
