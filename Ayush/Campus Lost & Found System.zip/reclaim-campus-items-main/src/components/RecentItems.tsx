
import { useApp } from "@/context/AppContext";
import { ItemCard } from "@/components/ItemCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export function RecentItems() {
  const { items } = useApp();
  
  // Get recent items (latest 6)
  const recentItems = items
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 6);

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Recent Lost & Found Items</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
              Browse the latest items that have been reported lost or found on campus.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-12">
          {recentItems.map((item) => (
            <ItemCard key={item.id} item={item} />
          ))}
        </div>
        <div className="flex justify-center">
          <Link to="/search">
            <Button className="gap-1">
              View All Items
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
