
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { statusInfo } from "@/services/mockData";
import { Item } from "@/types";
import { Calendar, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

interface ItemCardProps {
  item: Item;
}

export function ItemCard({ item }: ItemCardProps) {
  const { id, title, imageUrl, status, location, date, category } = item;
  const statusDetails = statusInfo[status];
  
  // Format the date
  const formattedDate = format(new Date(date), 'MMM d, yyyy');
  
  // Get icon based on status color
  const getStatusColor = () => {
    switch(status) {
      case "lost": return "bg-red-100 text-red-800 hover:bg-red-200";
      case "found": return "bg-green-100 text-green-800 hover:bg-green-200";
      case "claimed": return "bg-blue-100 text-blue-800 hover:bg-blue-200";
      default: return "bg-gray-100 text-gray-800 hover:bg-gray-200";
    }
  };

  return (
    <Link to={`/items/${id}`}>
      <Card className="overflow-hidden h-full transition-all hover:shadow-md">
        <CardHeader className="p-0">
          <div className="relative aspect-[4/3] w-full">
            <img 
              src={imageUrl} 
              alt={title}
              className="object-cover w-full h-full"
            />
            <Badge 
              className={`absolute top-2 left-2 ${getStatusColor()}`}
              variant="outline"
            >
              {statusDetails.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold line-clamp-1">{title}</h3>
          <div className="flex items-center text-sm text-muted-foreground mt-1">
            <MapPin className="w-3 h-3 mr-1" /> {location}
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center">
          <div className="flex items-center text-sm text-muted-foreground">
            <Calendar className="w-3 h-3 mr-1" /> {formattedDate}
          </div>
          <Badge variant="outline">{category}</Badge>
        </CardFooter>
      </Card>
    </Link>
  );
}
