
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
        <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
          <Link to="/" className="flex items-center space-x-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-white font-medium">
              L&F
            </div>
            <span className="font-semibold">Campus Lost & Found</span>
          </Link>
          <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
            © 2025 Campus Lost & Found. All rights reserved.
          </p>
        </div>
        <div className="flex gap-4">
          <Link 
            to="/about" 
            className="text-sm font-medium hover:underline underline-offset-4"
          >
            About
          </Link>
          <Link 
            to="/contact" 
            className="text-sm font-medium hover:underline underline-offset-4"
          >
            Contact
          </Link>
          <a 
            href="https://university.edu/policies" 
            target="_blank" 
            rel="noreferrer"
            className="text-sm font-medium hover:underline underline-offset-4"
          >
            Policies
          </a>
        </div>
      </div>
    </footer>
  )
}
