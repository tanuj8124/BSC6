
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { Toggle } from "@/components/ui/toggle";
import { ShieldCheck, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const Login = () => {
  const navigate = useNavigate();
  const { login, registerUser, isAuthenticated, isAdmin } = useApp();
  const [activeTab, setActiveTab] = useState("login");
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [loginData, setLoginData] = useState({ email: "", password: "" });
  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [loading, setLoading] = useState(false);
  const [emailConfirmationNeeded, setEmailConfirmationNeeded] = useState(false);
  const [registerSuccess, setRegisterSuccess] = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (isAuthenticated) {
      if (isAdmin) {
        navigate("/admin-dashboard");
      } else {
        navigate("/dashboard");
      }
    }
  }, [isAuthenticated, isAdmin, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setEmailConfirmationNeeded(false);
    
    try {
      const success = await login(loginData.email, loginData.password);
      if (!success) {
        // Login was not successful, but no exception was thrown
        // This is handled in the login function with appropriate toast messages
      }
    } catch (error: any) {
      console.error("Login error:", error);
      
      // Check if this is an email confirmation error
      if (error?.value?.code === "email_not_confirmed") {
        setEmailConfirmationNeeded(true);
      } else {
        toast({
          title: "Login error",
          description: error?.value?.message || "An unexpected error occurred during login. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setRegisterSuccess(false);
    
    if (registerData.password !== registerData.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
      });
      setLoading(false);
      return;
    }
    
    try {
      // Register the user with our new function
      const success = await registerUser(
        registerData.name, 
        registerData.email, 
        registerData.password
      );
      
      if (success) {
        // Clear the form and show success message
        setRegisterSuccess(true);
        setLoginData({ email: registerData.email, password: "" });
      }
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration error",
        description: "An unexpected error occurred during registration. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setEmailConfirmationNeeded(false);
    setRegisterSuccess(false);
  };

  const toggleAdminMode = () => {
    setIsAdminMode(!isAdminMode);
    // Reset the form data when switching modes
    setLoginData({ email: "", password: "" });
    setEmailConfirmationNeeded(false);
  };

  const handleDemoLogin = () => {
    if (isAdminMode) {
      setLoginData({ email: "admin@example.com", password: "admin123" });
    } else {
      setLoginData({ email: "user@example.com", password: "user123" });
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center py-12">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col justify-center space-y-6 mx-auto max-w-md">
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-bold">
                {isAdminMode ? "Admin Access" : "Welcome Back"}
              </h1>
              <p className="text-gray-500 dark:text-gray-400">
                {isAdminMode 
                  ? "Enter your admin credentials to access the dashboard" 
                  : "Enter your credentials to access your account"}
              </p>
            </div>

            <div className="flex justify-center mb-2">
              <Toggle 
                pressed={isAdminMode} 
                onPressedChange={toggleAdminMode}
                className="flex gap-2 items-center data-[state=on]:bg-amber-600"
              >
                <ShieldCheck className="h-4 w-4" />
                <span>{isAdminMode ? "Admin Login" : "Switch to Admin"}</span>
              </Toggle>
            </div>

            <div className="w-full">
              {isAdminMode ? (
                <Card className="border-amber-500">
                  <form onSubmit={handleLogin}>
                    <CardHeader className="bg-amber-50">
                      <CardTitle className="flex items-center gap-2">
                        <ShieldCheck className="h-5 w-5 text-amber-600" />
                        Admin Login
                      </CardTitle>
                      <CardDescription>
                        Restricted access for administrators
                      </CardDescription>
                    </CardHeader>
                    
                    {emailConfirmationNeeded && (
                      <div className="px-6 pt-4">
                        <Alert className="border-amber-500 bg-amber-50">
                          <AlertCircle className="h-4 w-4 text-amber-600" />
                          <AlertTitle>Email confirmation required</AlertTitle>
                          <AlertDescription>
                            Please check your email and confirm your account before logging in.
                          </AlertDescription>
                        </Alert>
                      </div>
                    )}
                    
                    <CardContent className="space-y-4 pt-6">
                      <div className="space-y-2">
                        <Label htmlFor="admin-email">Email</Label>
                        <Input
                          id="admin-email"
                          placeholder="admin@example.com"
                          required
                          type="email"
                          value={loginData.email}
                          onChange={(e) =>
                            setLoginData({ ...loginData, email: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="admin-password">Password</Label>
                        <Input
                          id="admin-password"
                          required
                          type="password"
                          value={loginData.password}
                          onChange={(e) =>
                            setLoginData({ ...loginData, password: e.target.value })
                          }
                        />
                      </div>
                      <div className="pt-2">
                        <Button 
                          type="button" 
                          variant="outline"
                          className="w-full text-amber-600 border-amber-300 hover:bg-amber-50"
                          onClick={handleDemoLogin}
                        >
                          Use Demo Admin Credentials
                        </Button>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        type="submit" 
                        className="w-full bg-amber-600 hover:bg-amber-700"
                        disabled={loading}
                      >
                        {loading ? "Logging in..." : "Login as Admin"}
                      </Button>
                    </CardFooter>
                  </form>
                </Card>
              ) : (
                <Tabs 
                  value={activeTab} 
                  onValueChange={handleTabChange}
                  className="w-full" 
                  id="auth-tabs"
                >
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="login">Login</TabsTrigger>
                    <TabsTrigger value="register">Register</TabsTrigger>
                  </TabsList>
                  <TabsContent value="login">
                    <Card>
                      <form onSubmit={handleLogin}>
                        <CardHeader>
                          <CardTitle>Login</CardTitle>
                          <CardDescription>
                            Enter your email and password to log in
                          </CardDescription>
                        </CardHeader>
                        
                        {emailConfirmationNeeded && (
                          <div className="px-6">
                            <Alert className="border-blue-500 bg-blue-50">
                              <AlertCircle className="h-4 w-4 text-blue-600" />
                              <AlertTitle>Email confirmation required</AlertTitle>
                              <AlertDescription>
                                Please check your email and confirm your account before logging in.
                              </AlertDescription>
                            </Alert>
                          </div>
                        )}
                        
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              placeholder="user@example.com"
                              required
                              type="email"
                              value={loginData.email}
                              onChange={(e) =>
                                setLoginData({ ...loginData, email: e.target.value })
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <Label htmlFor="password">Password</Label>
                              <a
                                className="text-sm text-primary underline-offset-4 hover:underline"
                                href="#"
                              >
                                Forgot your password?
                              </a>
                            </div>
                            <Input
                              id="password"
                              required
                              type="password"
                              value={loginData.password}
                              onChange={(e) =>
                                setLoginData({ ...loginData, password: e.target.value })
                              }
                            />
                          </div>
                          <div className="pt-2">
                            <Button 
                              type="button" 
                              variant="outline"
                              className="w-full"
                              onClick={handleDemoLogin}
                            >
                              Use Demo User Credentials
                            </Button>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            type="submit" 
                            className="w-full"
                            disabled={loading}
                          >
                            {loading ? "Logging in..." : "Login"}
                          </Button>
                        </CardFooter>
                      </form>
                    </Card>
                  </TabsContent>
                  <TabsContent value="register">
                    <Card>
                      <form onSubmit={handleRegister}>
                        <CardHeader>
                          <CardTitle>Create Account</CardTitle>
                          <CardDescription>
                            Enter your information to create an account
                          </CardDescription>
                        </CardHeader>
                        
                        {registerSuccess && (
                          <div className="px-6">
                            <Alert className="border-green-500 bg-green-50">
                              <AlertCircle className="h-4 w-4 text-green-600" />
                              <AlertTitle>Registration successful</AlertTitle>
                              <AlertDescription>
                                Please check your email to verify your account before logging in.
                              </AlertDescription>
                            </Alert>
                          </div>
                        )}
                        
                        <CardContent className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="register-name">Full Name</Label>
                            <Input
                              id="register-name"
                              placeholder="Your Name"
                              required
                              value={registerData.name}
                              onChange={(e) =>
                                setRegisterData({ ...registerData, name: e.target.value })
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="register-email">Email</Label>
                            <Input
                              id="register-email"
                              placeholder="your.email@example.com"
                              required
                              type="email"
                              value={registerData.email}
                              onChange={(e) =>
                                setRegisterData({ ...registerData, email: e.target.value })
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="register-password">Password</Label>
                            <Input
                              id="register-password"
                              required
                              type="password"
                              value={registerData.password}
                              onChange={(e) =>
                                setRegisterData({
                                  ...registerData,
                                  password: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="register-confirm-password">Confirm Password</Label>
                            <Input
                              id="register-confirm-password"
                              required
                              type="password"
                              value={registerData.confirmPassword}
                              onChange={(e) =>
                                setRegisterData({
                                  ...registerData,
                                  confirmPassword: e.target.value,
                                })
                              }
                            />
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            type="submit" 
                            className="w-full"
                            disabled={loading}
                          >
                            {loading ? "Creating Account..." : "Create Account"}
                          </Button>
                        </CardFooter>
                      </form>
                    </Card>
                  </TabsContent>
                </Tabs>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Login;
