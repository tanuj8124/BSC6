
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { statusInfo, categoryInfo } from "@/services/mockData";
import { format } from "date-fns";
import { 
  Calendar, 
  MapPin, 
  Mail, 
  Phone, 
  Tag, 
  Clock, 
  CheckCircle, 
  Trash2,
  ArrowLeft
} from "lucide-react";

const ItemDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { items, currentUser, updateItem, deleteItem } = useApp();
  const [isClaimDialogOpen, setIsClaimDialogOpen] = useState(false);
  
  const item = items.find((item) => item.id === id);
  
  if (!item) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 py-12">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 py-12 text-center">
              <h1 className="text-3xl font-bold">Item Not Found</h1>
              <p className="text-muted-foreground">
                The item you're looking for doesn't exist or has been removed.
              </p>
              <Button onClick={() => navigate("/search")}>
                <ArrowLeft className="mr-1 h-4 w-4" />
                Back to Search
              </Button>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  const formattedDate = format(new Date(item.date), 'MMMM d, yyyy');
  const isOwner = currentUser?.id === item.userId;
  const statusColor = item.status === "lost" 
    ? "bg-red-100 text-red-800"
    : item.status === "found"
    ? "bg-green-100 text-green-800"
    : "bg-blue-100 text-blue-800";
  
  const handleClaimItem = () => {
    updateItem(item.id, { status: "claimed" });
    setIsClaimDialogOpen(false);
  };
  
  const handleDeleteItem = () => {
    deleteItem(item.id);
    navigate("/dashboard");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate(-1)}
            className="mb-6"
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back
          </Button>
          
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <div className="overflow-hidden rounded-lg border bg-card">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-auto object-cover aspect-video"
                />
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center gap-2">
                <Badge className={statusColor}>{statusInfo[item.status].label}</Badge>
                <Badge variant="outline">{categoryInfo[item.category].label}</Badge>
              </div>
              
              <div>
                <h1 className="text-3xl font-bold">{item.title}</h1>
                <p className="text-muted-foreground mt-2">{item.description}</p>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{formattedDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tag className="h-4 w-4 text-muted-foreground" />
                    <span>{categoryInfo[item.category].label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Posted on {format(new Date(item.createdAt), 'MMMM d, yyyy')}</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                  <CardDescription>
                    Get in touch with the person who {item.status === "lost" ? "lost" : "found"} this item
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <a href={`mailto:${item.contactEmail}`} className="text-primary underline-offset-4 hover:underline">
                      {item.contactEmail}
                    </a>
                  </div>
                  {item.contactPhone && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${item.contactPhone}`} className="text-primary underline-offset-4 hover:underline">
                        {item.contactPhone}
                      </a>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <div className="flex gap-2">
                {isOwner && item.status !== "claimed" && (
                  <AlertDialog open={isClaimDialogOpen} onOpenChange={setIsClaimDialogOpen}>
                    <AlertDialogTrigger asChild>
                      <Button className="gap-1">
                        <CheckCircle className="h-4 w-4" />
                        Mark as Claimed
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Mark as Claimed</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to mark this item as claimed? This will remove it from active listings.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleClaimItem}>Continue</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
                
                {isOwner && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" className="gap-1">
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Item</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to remove this item from the listings? This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteItem} className="bg-destructive text-destructive-foreground">
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ItemDetail;
