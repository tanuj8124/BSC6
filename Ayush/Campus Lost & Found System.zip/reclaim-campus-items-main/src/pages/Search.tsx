
import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { ItemCard } from "@/components/ItemCard";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { statusInfo, categoryInfo, campusLocations } from "@/services/mockData";
import { SearchFilters, ItemStatus, ItemCategory } from "@/types";
import { Search as SearchIcon } from "lucide-react";

const Search = () => {
  const { filteredItems, filters, updateFilters } = useApp();
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilters(localFilters);
  };

  const updateLocalFilter = <K extends keyof SearchFilters>(
    key: K,
    value: SearchFilters[K]
  ) => {
    setLocalFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <section className="bg-muted py-10">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Search Lost & Found Items
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  Filter and search through all reported items
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="py-8">
          <div className="container px-4 md:px-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <form onSubmit={handleSearch} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
                  <div className="space-y-2">
                    <Input
                      placeholder="Search items..."
                      value={localFilters.query}
                      onChange={(e) => updateLocalFilter("query", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Select
                      value={localFilters.status}
                      onValueChange={(value) => 
                        updateLocalFilter("status", value as ItemStatus | "all")
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(statusInfo).map(([value, { label }]) => (
                          <SelectItem key={value} value={value}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Select
                      value={localFilters.category}
                      onValueChange={(value) =>
                        updateLocalFilter("category", value as ItemCategory | "all")
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(categoryInfo).map(([value, { label }]) => (
                          <SelectItem key={value} value={value}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Select
                      value={localFilters.location}
                      onValueChange={(value) =>
                        updateLocalFilter("location", value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Locations</SelectItem>
                        {campusLocations.map((location) => (
                          <SelectItem key={location} value={location}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button type="submit" className="gap-1">
                    <SearchIcon className="h-4 w-4" />
                    Search Items
                  </Button>
                </div>
              </form>
            </div>

            <div className="mt-8">
              <h2 className="text-2xl font-semibold mb-6">
                {filteredItems.length} {filteredItems.length === 1 ? 'Item' : 'Items'} Found
              </h2>
              {filteredItems.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredItems.map((item) => (
                    <ItemCard key={item.id} item={item} />
                  ))}
                </div>
              ) : (
                <div className="bg-muted/50 rounded-lg p-10 text-center">
                  <h3 className="text-lg font-medium">No items found</h3>
                  <p className="text-muted-foreground mt-1">
                    Try adjusting your search criteria
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Search;
