
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/components/ui/use-toast";
import { AlertCircle } from "lucide-react";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { 
    currentUser, 
    isAuthenticated, 
    isAdmin, 
    items, 
    siteSettings,
    updateSiteSetting,
    registeredUsers 
  } = useApp();
  const [activeTab, setActiveTab] = useState("overview");

  // Theme settings state
  const [themeSettings, setThemeSettings] = useState({
    primaryColor: siteSettings.site_theme?.primaryColor || "#3b82f6",
    secondaryColor: siteSettings.site_theme?.secondaryColor || "#6366f1",
    fontFamily: siteSettings.site_theme?.fontFamily || "Inter"
  });

  // Homepage settings state
  const [homepageSettings, setHomepageSettings] = useState({
    heroTitle: siteSettings.homepage_content?.heroTitle || "Campus Lost & Found",
    heroSubtitle: siteSettings.homepage_content?.heroSubtitle || "Quickly report and find lost items on campus",
    featuredItems: siteSettings.homepage_content?.featuredItems || 6
  });

  // Feature toggles state
  const [featureToggles, setFeatureToggles] = useState({
    enableSearch: siteSettings.features_config?.enableSearch ?? true,
    enableNotifications: siteSettings.features_config?.enableNotifications ?? false,
    enableLocationTracking: siteSettings.features_config?.enableLocationTracking ?? false
  });

  // Redirect if not authenticated or not admin
  if (!isAuthenticated || !currentUser) {
    navigate("/login");
    return null;
  }

  if (!isAdmin) {
    navigate("/dashboard");
    return null;
  }

  // Handle theme settings update
  const saveThemeSettings = async () => {
    const success = await updateSiteSetting('site_theme', themeSettings);
    if (success) {
      toast({
        title: "Theme settings saved",
        description: "The website theme has been updated successfully."
      });
    }
  };

  // Handle homepage settings update
  const saveHomepageSettings = async () => {
    const success = await updateSiteSetting('homepage_content', {
      ...homepageSettings,
      featuredItems: Number(homepageSettings.featuredItems)
    });
    if (success) {
      toast({
        title: "Homepage settings saved",
        description: "The homepage content has been updated successfully."
      });
    }
  };

  // Handle feature toggles update
  const saveFeatureToggles = async () => {
    const success = await updateSiteSetting('features_config', featureToggles);
    if (success) {
      toast({
        title: "Feature settings saved",
        description: "The feature toggles have been updated successfully."
      });
    }
  };

  const stats = {
    totalItems: items.length,
    lostItems: items.filter(item => item.status === "lost").length,
    foundItems: items.filter(item => item.status === "found").length,
    claimedItems: items.filter(item => item.status === "claimed").length,
    registeredUsers: registeredUsers.length
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col gap-8">
            <div>
              <h1 className="text-3xl font-bold">Admin Dashboard</h1>
              <p className="text-muted-foreground mt-2">
                Manage website settings and content
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-5">
              <Card className="bg-primary/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{stats.totalItems}</CardTitle>
                  <CardDescription>Total Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-red-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{stats.lostItems}</CardTitle>
                  <CardDescription>Lost Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-green-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{stats.foundItems}</CardTitle>
                  <CardDescription>Found Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-blue-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{stats.claimedItems}</CardTitle>
                  <CardDescription>Claimed Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-yellow-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{stats.registeredUsers}</CardTitle>
                  <CardDescription>Users</CardDescription>
                </CardHeader>
              </Card>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-4 w-full md:w-auto">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="theme">Theme</TabsTrigger>
                <TabsTrigger value="content">Content</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle>Admin Overview</CardTitle>
                    <CardDescription>
                      Welcome to the admin dashboard. Here you can manage all aspects of the Campus Lost & Found website.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Admin Access</AlertTitle>
                      <AlertDescription>
                        You have full administrative privileges. Be careful when making changes as they will affect all users.
                      </AlertDescription>
                    </Alert>
                    
                    <div className="mt-6">
                      <h3 className="text-lg font-semibold mb-3">Quick Actions</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Button 
                          variant="outline" 
                          onClick={() => navigate("/new-item")}
                          className="h-auto py-6 flex flex-col gap-2 items-center justify-center"
                        >
                          <span>Add New Item</span>
                          <span className="text-xs text-muted-foreground">Post a new lost or found item</span>
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => setActiveTab("theme")}
                          className="h-auto py-6 flex flex-col gap-2 items-center justify-center"
                        >
                          <span>Customize Theme</span>
                          <span className="text-xs text-muted-foreground">Change colors and appearance</span>
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => setActiveTab("features")}
                          className="h-auto py-6 flex flex-col gap-2 items-center justify-center"
                        >
                          <span>Manage Features</span>
                          <span className="text-xs text-muted-foreground">Enable or disable site features</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="theme">
                <Card>
                  <CardHeader>
                    <CardTitle>Theme Settings</CardTitle>
                    <CardDescription>
                      Customize the appearance of the website
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="primaryColor">Primary Color</Label>
                      <div className="flex gap-4 items-center">
                        <Input
                          id="primaryColor"
                          type="color"
                          value={themeSettings.primaryColor}
                          onChange={(e) => setThemeSettings({...themeSettings, primaryColor: e.target.value})}
                          className="w-16 h-12"
                        />
                        <Input
                          type="text"
                          value={themeSettings.primaryColor}
                          onChange={(e) => setThemeSettings({...themeSettings, primaryColor: e.target.value})}
                          className="flex-1"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="secondaryColor">Secondary Color</Label>
                      <div className="flex gap-4 items-center">
                        <Input
                          id="secondaryColor"
                          type="color"
                          value={themeSettings.secondaryColor}
                          onChange={(e) => setThemeSettings({...themeSettings, secondaryColor: e.target.value})}
                          className="w-16 h-12"
                        />
                        <Input
                          type="text"
                          value={themeSettings.secondaryColor}
                          onChange={(e) => setThemeSettings({...themeSettings, secondaryColor: e.target.value})}
                          className="flex-1"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="fontFamily">Font Family</Label>
                      <select
                        id="fontFamily"
                        value={themeSettings.fontFamily}
                        onChange={(e) => setThemeSettings({...themeSettings, fontFamily: e.target.value})}
                        className="w-full flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="Inter">Inter</option>
                        <option value="Roboto">Roboto</option>
                        <option value="Open Sans">Open Sans</option>
                        <option value="Montserrat">Montserrat</option>
                        <option value="Lato">Lato</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Preview</Label>
                      <div 
                        className="p-4 rounded-lg border"
                        style={{
                          backgroundColor: themeSettings.primaryColor + '10',
                          borderColor: themeSettings.primaryColor,
                          fontFamily: themeSettings.fontFamily
                        }}
                      >
                        <h3 
                          className="text-xl font-bold" 
                          style={{color: themeSettings.primaryColor}}
                        >
                          Sample Heading
                        </h3>
                        <p className="mt-2">This is what text will look like with your selected font family.</p>
                        <Button 
                          className="mt-3"
                          style={{
                            backgroundColor: themeSettings.primaryColor,
                          }}
                        >
                          Primary Button
                        </Button>
                        <Button 
                          variant="outline"
                          className="mt-3 ml-2"
                          style={{
                            borderColor: themeSettings.secondaryColor,
                            color: themeSettings.secondaryColor
                          }}
                        >
                          Secondary Button
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setThemeSettings({
                      primaryColor: "#3b82f6",
                      secondaryColor: "#6366f1",
                      fontFamily: "Inter"
                    })}>
                      Reset to Default
                    </Button>
                    <Button onClick={saveThemeSettings}>Save Changes</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="content">
                <Card>
                  <CardHeader>
                    <CardTitle>Content Settings</CardTitle>
                    <CardDescription>
                      Customize the content of the homepage
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="heroTitle">Hero Title</Label>
                      <Input
                        id="heroTitle"
                        value={homepageSettings.heroTitle}
                        onChange={(e) => setHomepageSettings({...homepageSettings, heroTitle: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="heroSubtitle">Hero Subtitle</Label>
                      <Input
                        id="heroSubtitle"
                        value={homepageSettings.heroSubtitle}
                        onChange={(e) => setHomepageSettings({...homepageSettings, heroSubtitle: e.target.value})}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="featuredItems">Featured Items Count</Label>
                      <Input
                        id="featuredItems"
                        type="number"
                        min="0"
                        max="12"
                        value={homepageSettings.featuredItems}
                        onChange={(e) => setHomepageSettings({...homepageSettings, featuredItems: e.target.value})}
                      />
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setHomepageSettings({
                      heroTitle: "Campus Lost & Found",
                      heroSubtitle: "Quickly report and find lost items on campus",
                      featuredItems: 6
                    })}>
                      Reset to Default
                    </Button>
                    <Button onClick={saveHomepageSettings}>Save Changes</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="features">
                <Card>
                  <CardHeader>
                    <CardTitle>Feature Management</CardTitle>
                    <CardDescription>
                      Enable or disable website features
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor="enableSearch" className="flex flex-col space-y-1">
                        <span>Enable Search</span>
                        <span className="font-normal text-xs text-muted-foreground">
                          Allow users to search for items
                        </span>
                      </Label>
                      <Switch
                        id="enableSearch"
                        checked={featureToggles.enableSearch}
                        onCheckedChange={(checked) => setFeatureToggles({...featureToggles, enableSearch: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor="enableNotifications" className="flex flex-col space-y-1">
                        <span>Enable Notifications</span>
                        <span className="font-normal text-xs text-muted-foreground">
                          Send email notifications to users
                        </span>
                      </Label>
                      <Switch
                        id="enableNotifications"
                        checked={featureToggles.enableNotifications}
                        onCheckedChange={(checked) => setFeatureToggles({...featureToggles, enableNotifications: checked})}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between space-x-2">
                      <Label htmlFor="enableLocationTracking" className="flex flex-col space-y-1">
                        <span>Enable Location Tracking</span>
                        <span className="font-normal text-xs text-muted-foreground">
                          Use device location for item reporting
                        </span>
                      </Label>
                      <Switch
                        id="enableLocationTracking"
                        checked={featureToggles.enableLocationTracking}
                        onCheckedChange={(checked) => setFeatureToggles({...featureToggles, enableLocationTracking: checked})}
                      />
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setFeatureToggles({
                      enableSearch: true,
                      enableNotifications: false,
                      enableLocationTracking: false
                    })}>
                      Reset to Default
                    </Button>
                    <Button onClick={saveFeatureToggles}>Save Changes</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminDashboard;
