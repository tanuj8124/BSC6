
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ItemStatus } from "@/types";
import { PlusCircle, Search } from "lucide-react";
import { ItemCard } from "@/components/ItemCard";

const Dashboard = () => {
  const navigate = useNavigate();
  const { items, currentUser, isAuthenticated } = useApp();
  const [activeTab, setActiveTab] = useState<ItemStatus | "all">("all");

  // Redirect if not authenticated
  if (!isAuthenticated || !currentUser) {
    navigate("/login");
    return null;
  }

  // Filter items by the current user and selected tab
  const userItems = items.filter((item) => item.userId === currentUser.id);
  const filteredItems = activeTab === "all" 
    ? userItems 
    : userItems.filter((item) => item.status === activeTab);

  // Count items by status
  const itemCounts = {
    all: userItems.length,
    lost: userItems.filter((item) => item.status === "lost").length,
    found: userItems.filter((item) => item.status === "found").length,
    claimed: userItems.filter((item) => item.status === "claimed").length,
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col gap-8">
            <div>
              <h1 className="text-3xl font-bold">My Dashboard</h1>
              <p className="text-muted-foreground mt-2">
                Manage your lost and found items
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-4">
              <Card className="bg-primary/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{itemCounts.all}</CardTitle>
                  <CardDescription>Total Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-red-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{itemCounts.lost}</CardTitle>
                  <CardDescription>Lost Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-green-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{itemCounts.found}</CardTitle>
                  <CardDescription>Found Items</CardDescription>
                </CardHeader>
              </Card>
              <Card className="bg-blue-100">
                <CardHeader className="pb-2">
                  <CardTitle className="text-2xl">{itemCounts.claimed}</CardTitle>
                  <CardDescription>Claimed Items</CardDescription>
                </CardHeader>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle>My Items</CardTitle>
                    <CardDescription>
                      Items you've reported as lost or found
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      onClick={() => navigate("/search")}
                      className="gap-1"
                    >
                      <Search className="h-4 w-4" />
                      Find Items
                    </Button>
                    <Button 
                      onClick={() => navigate("/new-item")}
                      className="gap-1"
                    >
                      <PlusCircle className="h-4 w-4" />
                      Post Item
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" onValueChange={(value) => setActiveTab(value as ItemStatus | "all")}>
                  <TabsList className="mb-6">
                    <TabsTrigger value="all">
                      All ({itemCounts.all})
                    </TabsTrigger>
                    <TabsTrigger value="lost">
                      Lost ({itemCounts.lost})
                    </TabsTrigger>
                    <TabsTrigger value="found">
                      Found ({itemCounts.found})
                    </TabsTrigger>
                    <TabsTrigger value="claimed">
                      Claimed ({itemCounts.claimed})
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value={activeTab}>
                    {filteredItems.length === 0 ? (
                      <div className="py-12 text-center">
                        <p className="text-xl font-semibold">No items found</p>
                        <p className="text-muted-foreground mt-1">
                          {activeTab === "all" 
                            ? "You haven't posted any items yet." 
                            : `You don't have any ${activeTab} items.`}
                        </p>
                        <Button
                          className="mt-4"
                          onClick={() => navigate("/new-item")}
                        >
                          Post an Item
                        </Button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredItems.map((item) => (
                          <ItemCard key={item.id} item={item} />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Dashboard;
