import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useApp } from "@/context/AppContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Item, ItemCategory, ItemStatus, ItemFormData } from "@/types";
import { categoryInfo, campusLocations } from "@/services/mockData";
import { toast } from "@/components/ui/use-toast";
import { Upload, Image as ImageIcon } from "lucide-react";

const NewItem = () => {
  const navigate = useNavigate();
  const { addItem, isAuthenticated } = useApp();
  const [formData, setFormData] = useState<Omit<ItemFormData, "userId" | "createdAt">>({
    title: "",
    description: "",
    category: "other" as ItemCategory,
    status: "lost" as ItemStatus,
    location: campusLocations[0],
    date: new Date().toISOString().split("T")[0],
    imageUrl: "",
    imageFile: null,
    contactEmail: "",
    contactPhone: "",
  });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Use useEffect for navigation instead of direct navigation in render
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      toast({
        title: "Authentication Required",
        description: "Please log in to submit items.",
        variant: "destructive",
      });
    }
  }, [isAuthenticated, navigate]);

  // Handle file selection and generate preview
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      // Update form data with the file
      setFormData((prev) => ({ 
        ...prev, 
        imageFile: file,
        // Keep imageUrl empty as we're using a file now
        imageUrl: ""
      }));
      
      // Create a preview URL
      const fileUrl = URL.createObjectURL(file);
      setPreviewUrl(fileUrl);
    }
  };

  // Clean up preview URL when component unmounts
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: keyof typeof formData) => (value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.imageFile) {
      toast({
        title: "Image Required",
        description: "Please upload an image of the item.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Convert the image file to a base64 string for storage
      // (This simulates what a backend would do to store the image)
      const base64Image = await convertFileToBase64(formData.imageFile);
      
      const itemToAdd: Omit<Item, "id" | "userId" | "createdAt"> = {
        ...formData,
        imageUrl: base64Image,
      };
      
      addItem(itemToAdd);
      navigate("/dashboard");
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error processing your image. Please try again.",
        variant: "destructive",
      });
      console.error("Image processing error:", error);
    }
  };

  // Function to convert File to base64 string
  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };

  
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-2xl">
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-bold">Submit a Lost or Found Item</h1>
              <p className="text-muted-foreground">
                Fill out the form below to report an item
              </p>
            </div>

            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Item Details</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="status">Item Type</Label>
                      <Select
                        name="status"
                        value={formData.status}
                        onValueChange={handleSelectChange("status")}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select item type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lost">Lost Item</SelectItem>
                          <SelectItem value="found">Found Item</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        name="title"
                        placeholder="Brief title describing the item"
                        required
                        value={formData.title}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        name="description"
                        placeholder="Provide detailed description of the item"
                        rows={4}
                        required
                        value={formData.description}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select
                        name="category"
                        value={formData.category}
                        onValueChange={handleSelectChange("category")}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(categoryInfo)
                            .filter(([key]) => key !== "all")
                            .map(([value, { label }]) => (
                              <SelectItem key={value} value={value}>
                                {label}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Select
                          name="location"
                          value={formData.location}
                          onValueChange={handleSelectChange("location")}
                          required
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select location" />
                          </SelectTrigger>
                          <SelectContent>
                            {campusLocations.map((location) => (
                              <SelectItem key={location} value={location}>
                                {location}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="date">Date</Label>
                        <Input
                          id="date"
                          name="date"
                          type="date"
                          required
                          value={formData.date}
                          onChange={handleChange}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="imageFile">Item Image</Label>
                      <div className="mt-1 flex items-center gap-4">
                        <label 
                          htmlFor="imageFile" 
                          className="flex h-32 w-32 cursor-pointer flex-col items-center justify-center rounded-md border border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100"
                        >
                          {previewUrl ? (
                            <img 
                              src={previewUrl} 
                              alt="Preview" 
                              className="h-full w-full rounded-md object-cover"
                            />
                          ) : (
                            <>
                              <Upload className="h-6 w-6 text-gray-400" />
                              <span className="mt-2 text-sm text-gray-500">Upload image</span>
                            </>
                          )}
                          <Input
                            id="imageFile"
                            name="imageFile"
                            type="file"
                            accept="image/*"
                            className="sr-only"
                            onChange={handleFileChange}
                            required
                          />
                        </label>
                        
                        {previewUrl && (
                          <div className="flex flex-col gap-2">
                            <p className="text-sm text-muted-foreground">Image selected</p>
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setFormData(prev => ({ ...prev, imageFile: null }));
                                if (previewUrl) {
                                  URL.revokeObjectURL(previewUrl);
                                  setPreviewUrl(null);
                                }
                              }}
                            >
                              Remove
                            </Button>
                          </div>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Upload an image of the item to help with identification
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <Label htmlFor="contactEmail">Contact Email</Label>
                        <Input
                          id="contactEmail"
                          name="contactEmail"
                          placeholder="Your email address"
                          type="email"
                          required
                          value={formData.contactEmail}
                          onChange={handleChange}
                        />
                      </div>
                      <div>
                        <Label htmlFor="contactPhone">Contact Phone</Label>
                        <Input
                          id="contactPhone"
                          name="contactPhone"
                          placeholder="Your phone number"
                          type="tel"
                          value={formData.contactPhone}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit">Submit Item</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default NewItem;
