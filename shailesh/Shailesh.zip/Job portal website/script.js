const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    menuToggle.classList.toggle('active');
});

document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        menuToggle.classList.remove('active');
    });
});

window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    const sections = document.querySelectorAll('section');
    const navItems = document.querySelectorAll('.nav-links a');
    let current = '';

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (pageYOffset >= sectionTop - 100) {
            current = section.getAttribute('id');
        }
    });

    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('href') === `#${current}`) {
            item.classList.add('active');
        }
    });
});

// Counter Animation
const counters = document.querySelectorAll('.counter');
const speed = 200;

function animateCounters() {
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;
        const increment = target / speed;
        
        if(count < target) {
            counter.innerText = Math.ceil(count + increment);
            setTimeout(animateCounters, 1);
        } else {
            counter.innerText = target;
        }
    });
}

// Run counters when section is in view
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if(entry.isIntersecting) {
            animateCounters();
            observer.unobserve(entry.target);
        }
    });
}, {threshold: 0.5});

document.querySelector('.stats').style.opacity = '0';
setTimeout(() => {
    document.querySelector('.stats').style.opacity = '1';
    observer.observe(document.querySelector('.stats'));
}, 100);

// FAQ Toggle
document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        const answer = question.nextElementSibling;
        const toggle = question.querySelector('.faq-toggle');
        
        if(answer.style.maxHeight) {
            answer.style.maxHeight = null;
            toggle.textContent = '+';
        } else {
            answer.style.maxHeight = answer.scrollHeight + 'px';
            toggle.textContent = '-';
        }
    });
})
  // Post a Job Modal functionality
  document.addEventListener('DOMContentLoaded', function() {
    const postJobBtn = document.querySelector('.secondary-btn');
    const postJobModal = document.getElementById('postJobModal');
    const closePostJobModal = document.getElementById('closePostJobModal');
    const postJobForm = document.getElementById('postJobForm');
    
    if (postJobBtn) {
        postJobBtn.addEventListener('click', function(e) {
            e.preventDefault();
            postJobModal.style.display = 'flex';
        });
    }
    
    if (closePostJobModal) {
        closePostJobModal.addEventListener('click', function() {
            postJobModal.style.display = 'none';
        });
    }
    
    // Close modal when clicking outside
    postJobModal.addEventListener('click', function(e) {
        if (e.target === postJobModal) {
            postJobModal.style.display = 'none';
        }
    });
    
    // Form submission
    if (postJobForm) {
        postJobForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Show success message
            alert('Job posted successfully!');
            postJobModal.style.display = 'none';
            postJobForm.reset();
        });
    }
});
// Login Modal functionality
document.addEventListener('DOMContentLoaded', function() {
const loginBtn = document.querySelector('.login-btn');
const loginModal = document.getElementById('loginModal');
const closeLoginModal = document.getElementById('closeLoginModal');
const loginForm = document.getElementById('loginForm');
const signupLink = document.getElementById('signupLink');

if (loginBtn) {
loginBtn.addEventListener('click', function(e) {
e.preventDefault();
loginModal.style.display = 'flex';
});
}

if (closeLoginModal) {
closeLoginModal.addEventListener('click', function() {
loginModal.style.display = 'none';
});
}

// Close modal when clicking outside
loginModal.addEventListener('click', function(e) {
if (e.target === loginModal) {
loginModal.style.display = 'none';
}
});

// Form submission
if (loginForm) {
loginForm.addEventListener('submit', function(e) {
e.preventDefault();
// Here you would typically validate and send login data to server
// For demo purposes, we'll just show an alert
const email = this.querySelector('input[type="email"]').value;
alert(`Login attempt for ${email}\n(In a real app, this would validate credentials)`);
loginModal.style.display = 'none';
loginForm.reset();
});
}

// Signup link - scroll to account creation section
if (signupLink) {
signupLink.addEventListener('click', function(e) {
e.preventDefault();
loginModal.style.display = 'none';
document.querySelector('.account-section').scrollIntoView({
    behavior: 'smooth'
});
});
}
});