<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database credentials
$host = "127.0.0.1";
$username = "root";
$password = "";
$database = "jobportaldb";

// Create connection
$conn = new mysqli('localhost', 'root', 'your_password', 'jobportaldb');


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get and sanitize form data
$name = mysqli_real_escape_string($conn, $_POST['name']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);

$resumePath = null; // Default value

// File upload handling
if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
    $fileTmpPath = $_FILES['resume']['tmp_name'];
    $fileName = basename($_FILES['resume']['name']);
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    $allowedExtensions = ['pdf', 'doc', 'docx'];

    if (in_array($fileExtension, $allowedExtensions)) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $newFileName = uniqid() . "_" . $fileName;
        $destPath = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpPath, $destPath)) {
            $resumePath = mysqli_real_escape_string($conn, $destPath);
        } else {
            die("Error moving uploaded file.");
        }
    } else {
        die("Invalid file type. Only PDF, DOC, and DOCX are allowed.");
    }
} else {
    die("Resume file is required.");
}

$sql = "INSERT INTO jobportal_db (name, email, phone, resume)
        VALUES ('$name', '$email', '$phone', '$resumePath')";

if ($conn->query($sql) === TRUE) {
    echo "Application submitted successfully.";
} else {
    echo "Error: " . $conn->error;
}
$conn->close();