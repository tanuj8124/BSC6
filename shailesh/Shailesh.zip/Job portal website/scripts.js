document.addEventListener('DOMContentLoaded', () => {
    // Test Message
    const testMessage = document.getElementById('test-message');
    if (testMessage) {
      testMessage.textContent = 'JavaScript is working!';
      setTimeout(() => {
        testMessage.style.display = 'none';
      }, 3000);
    }
  
    // Mobile Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (menuToggle && navLinks) {
      menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        menuToggle.classList.toggle('active');
      });
    }
  
    // Add Save Buttons to Job Cards
    document.querySelectorAll('.job-card').forEach(card => {
      const saveBtn = document.createElement('button');
      saveBtn.className = 'save-job-btn';
      saveBtn.innerHTML = '<i class="far fa-heart"></i>';
      card.querySelector('.job-card-header').prepend(saveBtn);
  
      saveBtn.addEventListener('click', function () {
        this.classList.toggle('saved');
        this.innerHTML = this.classList.contains('saved')
          ? '<i class="fas fa-heart"></i>'
          : '<i class="far fa-heart"></i>';
  
        const toast = document.getElementById('saveJobToast');
        if (toast) {
          toast.classList.add('show');
          setTimeout(() => toast.classList.remove('show'), 3000);
        }
      });
    });
  
    // Quick Apply Button
    const quickApplyBtn = document.createElement('div');
    quickApplyBtn.className = 'quick-apply-btn';
    quickApplyBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
    document.body.appendChild(quickApplyBtn);
  
    window.addEventListener('scroll', () => {
      quickApplyBtn.classList.toggle('show', window.scrollY > 300);
    });
  
    quickApplyBtn.addEventListener('click', () => {
      const firstJobCard = document.querySelector('.job-card');
      if (firstJobCard) {
        firstJobCard.scrollIntoView({ behavior: 'smooth' });
      }
    });
  
    // Enhanced Search Suggestions
    const jobTitleInput = document.getElementById('job-title');
    const suggestionsBox = document.getElementById('searchSuggestions');
  
    if (jobTitleInput && suggestionsBox) {
      // Store all job titles for suggestions
      const allJobTitles = Array.from(document.querySelectorAll('.job-title'))
        .map(el => el.textContent)
        .filter((value, index, self) => self.indexOf(value) === index);
  
      jobTitleInput.addEventListener('input', function () {
        const input = this.value.trim().toLowerCase();
  
        // Clear previous suggestions
        suggestionsBox.innerHTML = '';
        suggestionsBox.classList.remove('show');
  
        // Only show suggestions after 2 characters
        if (input.length < 2) return;
  
        // Filter matching titles
        const matchingTitles = allJobTitles.filter(title =>
          title.toLowerCase().includes(input)
        );
  
        // Show suggestions if matches found
        if (matchingTitles.length > 0) {
          suggestionsBox.innerHTML = matchingTitles
            .map(title => `<div class="suggestion-item">${title}</div>`)
            .join('');
          suggestionsBox.classList.add('show');
        }
      });
  
      // Handle suggestion selection
      suggestionsBox.addEventListener('click', function (e) {
        if (e.target.classList.contains('suggestion-item')) {
          jobTitleInput.value = e.target.textContent;
          suggestionsBox.classList.remove('show');
          filterJobs(); // Trigger search immediately
          jobTitleInput.focus(); // Keep focus on input
        }
      });
  
      // Close suggestions when clicking outside
      document.addEventListener('click', function (e) {
        if (!jobTitleInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
          suggestionsBox.classList.remove('show');
        }
      });
  
      // Close suggestions on escape key
      jobTitleInput.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
          suggestionsBox.classList.remove('show');
        }
      });
    }
  
    // Search Button Spinner
    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) {
      searchBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const spinner = document.getElementById('loadingSpinner');
        if (spinner) {
          spinner.style.display = 'flex';
          setTimeout(() => {
            spinner.style.display = 'none';
          }, 1500);
        }
      });
    }
  
    // Fetch Jobs from API
    async function fetchJobs() {
      try {
        const response = await fetch('http://localhost:8000/api/jobs/');
        if (!response.ok) throw new Error('Failed to fetch jobs');
        const jobs = await response.json();
        renderJobs(jobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        showToast('Error fetching jobs. Please try again later.', 'error');
      }
    }
  
    // Handle Job Application
    async function applyForJob(jobId, formData) {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:8000/api/jobs/${jobId}/apply/`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          body: formData,
        });
  
        if (!response.ok) throw new Error('Application failed');
        return await response.json();
      } catch (error) {
        console.error('Application error:', error);
        showToast('Application failed. Please try again.', 'error');
        throw error;
      }
    }
  
    // Utility Function to Show Toast Messages
    function showToast(message, type = 'info') {
      const toast = document.createElement('div');
      toast.innerHTML = `
        <div style="position: fixed; bottom: 20px; right: 20px; background: ${
          type === 'error' ? '#ef4444' : '#1e3a8a'
        }; color: white; padding: 15px 25px; border-radius: 5px; display: flex; align-items: center; gap: 10px; z-index: 1000;">
          <i class="fas ${type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
          <span>${message}</span>
        </div>
      `;
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 3000);
    }
  });

  document.addEventListener('DOMContentLoaded', function() {

        
        document.body.appendChild(modal);
        
        // Handle form submission
        modal.querySelector('#applicationForm').addEventListener('submit', function(e) {
          e.preventDefault();
          const submitBtn = modal.querySelector('button[type="submit"]');
          submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
          submitBtn.disabled = true;
          
          // Simulate form submission
          setTimeout(() => {
            modal.remove();
            showToast('Application submitted successfully!', 'success');
          }, 1500);
        });
        
        // Handle cancel
        modal.querySelector('#cancelApply').addEventListener('click', () => {
          modal.remove();
        });
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
          if (e.target === modal) {
            modal.remove();
          }
        });
      });
  
    
    // Helper function to show toast notifications
    function showToast(message, type) {
      const toast = document.createElement('div');
      toast.style.position = 'fixed';
      toast.style.bottom = '20px';
      toast.style.right = '20px';
      toast.style.backgroundColor = type === 'success' ? '#22c55e' : '#ef4444';
      toast.style.color = 'white';
      toast.style.padding = '15px 25px';
      toast.style.borderRadius = '8px';
      toast.style.display = 'flex';
      toast.style.alignItems = 'center';
      toast.style.gap = '10px';
      toast.style.zIndex = '1000';
      toast.style.boxShadow = '0 10px 15px rgba(0, 0, 0, 0.1)';
      toast.style.animation = 'slideIn 0.3s ease-out';
      
      toast.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <span>${message}</span>
      `;
      
      document.body.appendChild(toast);
      
      setTimeout(() => {
        toast.remove();
      }, 3000);
    }


  document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchBtn = document.querySelector('.search-btn');
    const jobTitleInput = document.getElementById('job-title');
    const locationInput = document.getElementById('location');
    const jobCards = document.querySelectorAll('.job-card');
    
    searchBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Get search terms
      const jobTitleTerm = jobTitleInput.value.trim().toLowerCase();
      const locationTerm = locationInput.value.trim().toLowerCase();
      
      // Show loading spinner
      const spinner = document.getElementById('loadingSpinner');
      spinner.style.display = 'flex';
      
      // Simulate search delay (remove in production)
      setTimeout(() => {
        let hasResults = false;
        
        jobCards.forEach(card => {
          const title = card.querySelector('.job-title').textContent.toLowerCase();
          const location = card.querySelector('.meta-item i.fa-map-marker-alt') 
            ? card.querySelector('.meta-item i.fa-map-marker-alt').parentNode.textContent.toLowerCase()
            : '';
          
          // Check if matches search terms
          const titleMatch = jobTitleTerm === '' || title.includes(jobTitleTerm);
          const locationMatch = locationTerm === '' || location.includes(locationTerm);
          
          if (titleMatch && locationMatch) {
            card.style.display = 'block';
            hasResults = true;
          } else {
            card.style.display = 'none';
          }
        });
        
        // Hide spinner
        spinner.style.display = 'none';
        
        // Show message if no results
        if (!hasResults) {
          const toast = document.getElementById('saveJobToast');
          toast.querySelector('i').className = 'fas fa-exclamation-circle';
          toast.textContent = 'No jobs found matching your criteria';
          toast.classList.add('show');
          
          setTimeout(() => {
            toast.classList.remove('show');
            // Reset to original state
            setTimeout(() => {
              toast.querySelector('i').className = 'fas fa-check-circle';
              toast.innerHTML = '<i class="fas fa-check-circle"></i> Job saved successfully!';
            }, 300);
          }, 3000);
        }
      }, 500); // Simulate network delay
    });
    
    // Reset search when inputs are cleared
    [jobTitleInput, locationInput].forEach(input => {
      input.addEventListener('input', function() {
        if (this.value.trim() === '') {
          jobCards.forEach(card => {
            card.style.display = 'block';
          });
        }
      });
    });
  });