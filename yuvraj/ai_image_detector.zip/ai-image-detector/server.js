const express = require('express');
const multer = require('multer');
const fs = require('fs');
const app = express();
const port = 3000;

// Setup file upload
const upload = multer({ dest: 'uploads/' });
app.use(express.static(__dirname));

// Dummy AI-generated image detection logic
function isAIGenerated(filename) {
    const stats = fs.statSync(filename);
    // Example: if image size is < 100 KB, assume it's AI-generated (just for demo)
    return stats.size < 100000;
}

// API endpoint
app.post('/analyze', upload.single('image'), (req, res) => {
    const isFake = isAIGenerated(req.file.path);
    fs.unlinkSync(req.file.path); // Delete file after checking
    res.json({ result: isFake ? "AI-Generated" : "Real Image" });
});

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));