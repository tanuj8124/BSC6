from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from app.models import Student, Room, LeaveApplication
from app import db
from datetime import datetime

student_bp = Blueprint('student', __name__)

@student_bp.route('/apply-hostel', methods=['POST'])
@login_required
def apply_hostel():
    if current_user.is_admin:
        return jsonify({'error': 'Admins cannot apply for hostel'}), 403
    
    data = request.get_json()
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    if not student:
        return jsonify({'error': 'Student profile not found'}), 404
    
    # Update student application
    student.course = data.get('course', student.course)
    student.year = data.get('year', student.year)
    student.phone = data.get('phone', student.phone)
    student.address = data.get('address', student.address)
    student.status = 'pending'
    
    db.session.commit()
    return jsonify({'message': 'Hostel application submitted successfully'})

@student_bp.route('/check-status')
@login_required
def check_status():
    student = Student.query.filter_by(user_id=current_user.id).first()
    if not student:
        return jsonify({'error': 'Student profile not found'}), 404
    
    return jsonify({
        'status': student.status,
        'room': {
            'block': student.room.block if student.room else None,
            'number': student.room.number if student.room else None,
            'type': student.room.type if student.room else None
        } if student.room else None
    })

@student_bp.route('/apply-leave', methods=['POST'])
@login_required
def apply_leave():
    data = request.get_json()
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    if not student:
        return jsonify({'error': 'Student profile not found'}), 404
    
    leave = LeaveApplication(
        student_id=student.id,
        reason=data['reason'],
        from_date=datetime.strptime(data['from_date'], '%Y-%m-%d').date(),
        to_date=datetime.strptime(data['to_date'], '%Y-%m-%d').date(),
        contact_number=data['contact_number'],
        address_during_leave=data['address_during_leave']
    )
    db.session.add(leave)
    db.session.commit()
    
    return jsonify({'message': 'Leave application submitted successfully'})