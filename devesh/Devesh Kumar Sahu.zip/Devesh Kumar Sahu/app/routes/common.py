from flask import Blueprint, jsonify
from app.models import Room, MessMenu
from datetime import datetime

common_bp = Blueprint('common', __name__)

@common_bp.route('/rooms', methods=['GET'])
def get_rooms():
    rooms = Room.query.all()
    
    result = []
    for room in rooms:
        result.append({
            'id': room.id,
            'block': room.block,
            'number': room.number,
            'type': room.type,
            'capacity': room.capacity,
            'current_occupancy': room.current_occupancy
        })
    
    return jsonify(result)

@common_bp.route('/mess-menu', methods=['GET'])
def get_mess_menu():
    date = request.args.get('date', datetime.today().strftime('%Y-%m-%d'))
    
    menu = MessMenu.query.filter_by(date=datetime.strptime(date, '%Y-%m-%d').date()).first()
    
    if not menu:
        return jsonify({'error': 'Menu not found for this date'}), 404
    
    return jsonify({
        'date': menu.date.strftime('%Y-%m-%d'),
        'breakfast': menu.breakfast,
        'lunch': menu.lunch,
        'dinner': menu.dinner,
        'special': menu.special
    })