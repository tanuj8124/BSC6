from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from app.models import Student, Room, LeaveApplication, MessMenu
from app import db
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/applications')
@login_required
def get_applications():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    status = request.args.get('status', 'pending')
    applications = Student.query.filter_by(status=status).all()
    
    result = []
    for app in applications:
        result.append({
            'id': app.id,
            'roll_number': app.roll_number,
            'full_name': app.full_name,
            'course': app.course,
            'year': app.year,
            'applied_on': app.created_at.strftime('%Y-%m-%d'),
            'status': app.status
        })
    
    return jsonify(result)

@admin_bp.route('/approve-application/<int:student_id>', methods=['POST'])
@login_required
def approve_application(student_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    student = Student.query.get(student_id)
    if not student:
        return jsonify({'error': 'Student not found'}), 404
    
    data = request.get_json()
    
    # Assign room
    room = Room.query.get(data['room_id'])
    if room.current_occupancy >= room.capacity:
        return jsonify({'error': 'Room is full'}), 400
    
    student.status = 'approved'
    student.room_id = room.id
    room.current_occupancy += 1
    
    db.session.commit()
    return jsonify({'message': 'Application approved and room allotted'})

@admin_bp.route('/leave-applications')
@login_required
def get_leave_applications():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    status = request.args.get('status', 'pending')
    leaves = LeaveApplication.query.filter_by(status=status).all()
    
    result = []
    for leave in leaves:
        result.append({
            'id': leave.id,
            'student_name': leave.student.full_name,
            'roll_number': leave.student.roll_number,
            'reason': leave.reason,
            'from_date': leave.from_date.strftime('%Y-%m-%d'),
            'to_date': leave.to_date.strftime('%Y-%m-%d'),
            'status': leave.status
        })
    
    return jsonify(result)

@admin_bp.route('/update-mess-menu', methods=['POST'])
@login_required
def update_mess_menu():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    
    menu = MessMenu(
        date=datetime.strptime(data['date'], '%Y-%m-%d').date(),
        breakfast=data['breakfast'],
        lunch=data['lunch'],
        dinner=data['dinner'],
        special=data.get('special')
    )
    db.session.add(menu)
    db.session.commit()
    
    return jsonify({'message': 'Mess menu updated successfully'})