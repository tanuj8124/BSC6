from app import create_app, db
from app.models import User, Student, Room, LeaveApplication, MessMenu
import click
from flask.cli import with_appcontext

app = create_app()

@app.cli.command("init-db")
@with_appcontext
def init_db_command():
    """Initialize the database."""
    db.create_all()
    
    # Create admin user if not exists
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            email='admin@hostel.com',
            password='admin123',  # In production, use generate_password_hash
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        print('Admin user created')
    
    print('Database initialized')

# Add this function to make it easier to init the DB
def init_db():
    with app.app_context():
        init_db_command()

if __name__ == '__main__':
    app.run(debug=True)